
$(function (){

    $("#sub_btn").click((function (){
        //用户名<4
        if($("[name='username']").val()==null){
            alert("用户名为空");
            return false;
        }
        //密码不为空且长度>=8
        if ($("[name='password']").val()==null) {
            alert("密码不可为空");
            return false;
        }
        //两次密码相同
        if ($("[name='password']").val().length<8) {
            alert("密码长度不可小于8");
            return false;
        }
        else {
            alert("登录成功");
            window.open('../employee/employee.jsp');
        }

    }))

})