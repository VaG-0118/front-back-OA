package com.universityhr.utils;

import com.alibaba.druid.pool.DruidDataSourceFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Properties;

public class JDBCUtils {
        private static DataSource dataSource;
        private static ThreadLocal<Connection> threadLocal;

        static {
            //创建properties文件，读流，加载
            try {
                Properties properties = new Properties();
                properties.load(JDBCUtils.class.getClassLoader().getResourceAsStream("jdbc.properties"));
                //连接连接池
                dataSource = DruidDataSourceFactory.createDataSource(properties);
                //连接线程池
                threadLocal = new ThreadLocal<>();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        //从线程池获得连接
        public static Connection getConnection() {
            Connection connection = threadLocal.get();
            if(connection==null) {
                try {
                    connection = dataSource.getConnection();
                    threadLocal.set(connection);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return connection;
        }
        //释放连接
        public static void releaseConnection() {
            Connection conneciton = threadLocal.get();
            if(conneciton!=null) {
                try {
                    conneciton.close();
                    threadLocal.remove();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
}
