package com.universityhr.bean;

import java.util.List;

public class Page<T>
{
    // 每页中的数据存放的集合
    private List<T> list;
    // 每页显示的数据的条数
    private int pageSize = 10;
    // 当前页码
    private int pageNo;
    // 总记录数，通过查询数据库得到
    private int totalRecord;

    public List<T> getList()
    {
        return list;
    }

    public void setList(List<T> list)
    {
        this.list = list;
    }

    public int getPageSize()
    {
        return this.pageSize;
    }

    public void setPageSize(int pageSize)
    {
        this.pageSize = pageSize;
    }

    public int getPageNo()
    {
        //如果当前页小于1
        if (pageNo < 1)
        {
            return 1;
        }
        //如果当前页大于总页数
        else if (pageNo > getTotalPageNo())
        {
            return getTotalPageNo();
        }
        else
        {
            return pageNo;
        }
    }

    public void setPageNo(int pageNo)
    {
        this.pageNo = pageNo;
    }

    //总页数由总记录数和每页显示的条数计算得到
    public int getTotalPageNo()
    {
        if (totalRecord % pageSize == 0)
        {
            return totalRecord / pageSize;
        }
        else
        {
            return totalRecord / pageSize + 1;
        }
    }


    public int getTotalRecord()
    {
        return totalRecord;
    }

    public void setTotalRecord(int totalRecord)
    {
        this.totalRecord = totalRecord;
    }
}
