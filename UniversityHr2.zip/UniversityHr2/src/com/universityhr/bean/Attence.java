package com.universityhr.bean;

public class Attence
{
    // 出勤信息编号
    private Integer id;
    // 员工ID
    private Integer empID;
    // 员工姓名
    private String empName;
    // 员工性别
    private Integer gender;
    // 员工部门名
    private String deptName;
    // 员工在职状态
    private Integer empStatus;
    // 考勤情况
    private String attenceInfo;
    // 日期
    private String date;

    public Attence()
    {
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getEmpID()
    {
        return empID;
    }

    public void setEmpID(Integer empID)
    {
        this.empID = empID;
    }

    public String getEmpName()
    {
        return empName;
    }

    public void setEmpName(String empName)
    {
        this.empName = empName;
    }

    public Integer getGender()
    {
        return gender;
    }

    public void setGender(Integer gender)
    {
        this.gender = gender;
    }

    public String getDeptName()
    {
        return deptName;
    }

    public void setDeptName(String deptName)
    {
        this.deptName = deptName;
    }

    public Integer getEmpStatus()
    {
        return empStatus;
    }

    public void setEmpStatus(Integer empStatus)
    {
        this.empStatus = empStatus;
    }

    public String getAttenceInfo()
    {
        return attenceInfo;
    }

    public void setAttenceInfo(String attenceInfo)
    {
        this.attenceInfo = attenceInfo;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    @Override
    public String toString()
    {
        return "Attence{" +
                "id=" + id +
                ", empID=" + empID +
                ", empName='" + empName + '\'' +
                ", gender=" + gender +
                ", deptName='" + deptName + '\'' +
                ", empStatus=" + empStatus +
                ", attenceInfo='" + attenceInfo + '\'' +
                ", date='" + date + '\'' +
                '}';
    }
}
