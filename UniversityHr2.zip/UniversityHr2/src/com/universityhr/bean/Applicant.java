package com.universityhr.bean;

public class Applicant
{
    // 应聘编号
    private Integer id;
    // 应聘者姓名
    private String personName;
    // 性别
    private Integer gender;
    // 目的岗位
    private String purposePost;
    // 学历
    private String education;
    // 是否有工作经验
    private Integer workExperience;
    // 目前招聘状态(通过、失败等)
    private Integer passStatus;
    // 邮箱
    private String emailAddr;
    // QQ
    private String QQ;
    // 工作经验详情
    private String workExpDetail;
    // 其他经验详情
    private String otherExpDetail;
    // 电话
    private String telephone;
    // 提交日期
    private String submitDate;
    // 期望薪资
    private Integer purposeSalary;

    public Applicant()
    {
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getPersonName()
    {
        return personName;
    }

    public void setPersonName(String personName)
    {
        this.personName = personName;
    }

    public Integer getGender()
    {
        return gender;
    }

    public void setGender(Integer gender)
    {
        this.gender = gender;
    }

    public String getPurposePost()
    {
        return purposePost;
    }

    public void setPurposePost(String purposePost)
    {
        this.purposePost = purposePost;
    }

    public String getEducation()
    {
        return education;
    }

    public void setEducation(String education)
    {
        this.education = education;
    }

    public Integer getWorkExperience()
    {
        return workExperience;
    }

    public void setWorkExperience(Integer workExperience)
    {
        this.workExperience = workExperience;
    }

    public Integer getPassStatus()
    {
        return passStatus;
    }

    public void setPassStatus(Integer passStatus)
    {
        this.passStatus = passStatus;
    }

    public String getEmailAddr()
    {
        return emailAddr;
    }

    public void setEmailAddr(String emailAddr)
    {
        this.emailAddr = emailAddr;
    }

    public String getQQ()
    {
        return QQ;
    }

    public void setQQ(String QQ)
    {
        this.QQ = QQ;
    }

    public String getWorkExpDetail()
    {
        return workExpDetail;
    }

    public void setWorkExpDetail(String workExpDetail)
    {
        this.workExpDetail = workExpDetail;
    }

    public String getOtherExpDetail()
    {
        return otherExpDetail;
    }

    public void setOtherExpDetail(String otherExpDetail)
    {
        this.otherExpDetail = otherExpDetail;
    }

    public String getTelephone()
    {
        return telephone;
    }

    public void setTelephone(String telephone)
    {
        this.telephone = telephone;
    }

    public String getSubmitDate()
    {
        return submitDate;
    }

    public void setSubmitDate(String submitDate)
    {
        this.submitDate = submitDate;
    }

    public Integer getPurposeSalary()
    {
        return purposeSalary;
    }

    public void setPurposeSalary(Integer purposeSalary)
    {
        this.purposeSalary = purposeSalary;
    }

    @Override
    public String toString()
    {
        return "Applicant{" +
                "id=" + id +
                ", personName='" + personName + '\'' +
                ", gender=" + gender +
                ", purposePost='" + purposePost + '\'' +
                ", education='" + education + '\'' +
                ", workExperience=" + workExperience +
                ", passStatus=" + passStatus +
                ", emailAddr='" + emailAddr + '\'' +
                ", QQ='" + QQ + '\'' +
                ", workExpDetail='" + workExpDetail + '\'' +
                ", otherExpDetail='" + otherExpDetail + '\'' +
                ", telephone='" + telephone + '\'' +
                ", submitDate='" + submitDate + '\'' +
                ", purposeSalary=" + purposeSalary +
                '}';
    }
}
