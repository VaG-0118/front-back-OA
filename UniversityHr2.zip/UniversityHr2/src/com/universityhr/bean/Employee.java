package com.universityhr.bean;

public class Employee
{
    // 员工ID
    private Integer empID;
    // 员工名
    private String empName;
    // 性别
    private Integer gender;
    // 生日
    private String birthday;
    // 政治面貌
    private Integer politicalStatus;
    // 部门编号
    private Integer deptNO;
    // 职称
    private String professionalTitle;
    // 在职状况
    private Integer empStatus;
    // 员工住址
    private String empAddress;
    // 邮箱
    private String emailAddr;
    // 电话
    private String telephone;
    // QQ
    private String QQ;
    // 学历
    private String education;
    // 毕业院校
    private String university;
    // 简介
    private String intro;


    public Employee()
    {
    }

    public Employee(Integer empID, String empName, Integer gender, String birthday, Integer politicalStatus, Integer deptNO, String professionalTitle, Integer empStatus, String empAddress, String emailAddr, String telephone, String QQ, String education, String university, String intro)
    {
        this.empID = empID;
        this.empName = empName;
        this.gender = gender;
        this.birthday = birthday;
        this.politicalStatus = politicalStatus;
        this.deptNO = deptNO;
        this.professionalTitle = professionalTitle;
        this.empStatus = empStatus;
        this.empAddress = empAddress;
        this.emailAddr = emailAddr;
        this.telephone = telephone;
        this.QQ = QQ;
        this.education = education;
        this.university = university;
        this.intro = intro;
    }

    public Integer getEmpID()
    {
        return empID;
    }

    public void setEmpID(Integer empID)
    {
        this.empID = empID;
    }

    public String getEmpName()
    {
        return empName;
    }

    public void setEmpName(String empName)
    {
        this.empName = empName;
    }

    public Integer getGender()
    {
        return gender;
    }

    public void setGender(Integer gender)
    {
        this.gender = gender;
    }

    public String getBirthday()
    {
        return birthday;
    }

    public void setBirthday(String birthday)
    {
        this.birthday = birthday;
    }

    public Integer getPoliticalStatus()
    {
        return politicalStatus;
    }

    public void setPoliticalStatus(Integer politicalStatus)
    {
        this.politicalStatus = politicalStatus;
    }

    public Integer getDeptNO()
    {
        return deptNO;
    }

    public void setDeptNO(Integer deptNO)
    {
        this.deptNO = deptNO;
    }

    public String getProfessionalTitle()
    {
        return professionalTitle;
    }

    public void setProfessionalTitle(String professionalTitle)
    {
        this.professionalTitle = professionalTitle;
    }

    public Integer getEmpStatus()
    {
        return empStatus;
    }

    public void setEmpStatus(Integer empStatus)
    {
        this.empStatus = empStatus;
    }

    public String getEmpAddress()
    {
        return empAddress;
    }

    public void setEmpAddress(String empAddress)
    {
        this.empAddress = empAddress;
    }

    public String getEmailAddr()
    {
        return emailAddr;
    }

    public void setEmailAddr(String emailAddr)
    {
        this.emailAddr = emailAddr;
    }

    public String getTelephone()
    {
        return telephone;
    }

    public void setTelephone(String telephone)
    {
        this.telephone = telephone;
    }

    public String getQQ()
    {
        return QQ;
    }

    public void setQQ(String QQ)
    {
        this.QQ = QQ;
    }

    public String getEducation()
    {
        return education;
    }

    public void setEducation(String education)
    {
        this.education = education;
    }

    public String getUniversity()
    {
        return university;
    }

    public void setUniversity(String university)
    {
        this.university = university;
    }

    public String getIntro()
    {
        return intro;
    }

    public void setIntro(String intro)
    {
        this.intro = intro;
    }

    @Override
    public String toString()
    {
        return "Employee{" +
                "empID=" + empID +
                ", empName='" + empName + '\'' +
                ", gender=" + gender +
                ", birthday='" + birthday + '\'' +
                ", politicalStatus=" + politicalStatus +
                ", deptNO=" + deptNO +
                ", professionalTitle='" + professionalTitle + '\'' +
                ", empStatus=" + empStatus +
                ", empAddress='" + empAddress + '\'' +
                ", emailAddr='" + emailAddr + '\'' +
                ", telephone='" + telephone + '\'' +
                ", QQ='" + QQ + '\'' +
                ", education='" + education + '\'' +
                ", university='" + university + '\'' +
                ", intro='" + intro + '\'' +
                '}';
    }
}
