package com.universityhr.bean;

public class File
{
    // ID
    private Integer id;
    // 文件名
    private String fileName;
    // 文件类型
    private String fileType;
    // 发布者/作者
    private String author;
    // 发布日期
    private String date;

    public File()
    {
    }

    public File(Integer id, String fileName, String fileType, String author, String date)
    {
        this.id = id;
        this.fileName = fileName;
        this.fileType = fileType;
        this.author = author;
        this.date = date;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getFileName()
    {
        return fileName;
    }

    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }

    public String getFileType()
    {
        return fileType;
    }

    public void setFileType(String fileType)
    {
        this.fileType = fileType;
    }

    public String getAuthor()
    {
        return author;
    }

    public void setAuthor(String author)
    {
        this.author = author;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    @Override
    public String toString()
    {
        return "File{" +
                "id=" + id +
                ", fileName='" + fileName + '\'' +
                ", fileType='" + fileType + '\'' +
                ", author='" + author + '\'' +
                ", date='" + date + '\'' +
                '}';
    }
}
