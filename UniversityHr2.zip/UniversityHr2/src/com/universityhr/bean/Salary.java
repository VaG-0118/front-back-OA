package com.universityhr.bean;

public class Salary
{
    // 编号
    private Integer id;
    // 员工ID
    private Integer empID;
    // 员工姓名
    private String empName;
    // 部门编号
    private Integer deptNO;
    // 部门名称
    private String deptName;
    // 工作岗位
    private String job;
    // 标准薪资
    private Double standardSalary;
    // 奖金
    private Double bonus;
    // 工作补贴
    private Double workSubsidy;
    // 加班费
    private Double overtimePay;
    // 迟到扣除
    private Double belate;
    // 请假
    private Double leave;
    // 旷工
    private Double absent;
    // 社保费用
    private Double socialInsurance;
    // 日期
    private String date;

    public Salary()
    {
    }

    public String getEmpName()
    {
        return empName;
    }

    public void setEmpName(String empName)
    {
        this.empName = empName;
    }

    public String getDeptName()
    {
        return deptName;
    }

    public void setDeptName(String deptName)
    {
        this.deptName = deptName;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getEmpID()
    {
        return empID;
    }

    public void setEmpID(Integer empID)
    {
        this.empID = empID;
    }

    public Integer getDeptNO()
    {
        return deptNO;
    }

    public void setDeptNO(Integer deptNO)
    {
        this.deptNO = deptNO;
    }

    public String getJob()
    {
        return job;
    }

    public void setJob(String job)
    {
        this.job = job;
    }

    public Double getStandardSalary()
    {
        return standardSalary;
    }

    public void setStandardSalary(Double standardSalary)
    {
        this.standardSalary = standardSalary;
    }

    public Double getBonus()
    {
        return bonus;
    }

    public void setBonus(Double bonus)
    {
        this.bonus = bonus;
    }

    public Double getWorkSubsidy()
    {
        return workSubsidy;
    }

    public void setWorkSubsidy(Double workSubsidy)
    {
        this.workSubsidy = workSubsidy;
    }

    public Double getOvertimePay()
    {
        return overtimePay;
    }

    public void setOvertimePay(Double overtimePay)
    {
        this.overtimePay = overtimePay;
    }

    public Double getBelate()
    {
        return belate;
    }

    public void setBelate(Double belate)
    {
        this.belate = belate;
    }

    public Double getLeave()
    {
        return leave;
    }

    public void setLeave(Double leave)
    {
        this.leave = leave;
    }

    public Double getAbsent()
    {
        return absent;
    }

    public void setAbsent(Double absent)
    {
        this.absent = absent;
    }

    public Double getSocialInsurance()
    {
        return socialInsurance;
    }

    public void setSocialInsurance(Double socialInsurance)
    {
        this.socialInsurance = socialInsurance;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    @Override
    public String toString()
    {
        return "Salary{" +
                "id=" + id +
                ", empID=" + empID +
                ", deptNO=" + deptNO +
                ", job='" + job + '\'' +
                ", standardSalary=" + standardSalary +
                ", bonus=" + bonus +
                ", workSubsidy=" + workSubsidy +
                ", overtimePay=" + overtimePay +
                ", belate=" + belate +
                ", leave=" + leave +
                ", absent=" + absent +
                ", socialInsurance=" + socialInsurance +
                ", date='" + date + '\'' +
                '}';
    }
}
