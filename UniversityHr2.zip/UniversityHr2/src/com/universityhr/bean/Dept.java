package com.universityhr.bean;

public class Dept
{
    // 部门编号
    private Integer deptNO;
    // 部门名称
    private String deptName;
    // 部门类型
    private String deptType;


    public Dept()
    {
    }

    public Dept(Integer deptNO, String deptName, String deptType)
    {
        this.deptNO = deptNO;
        this.deptName = deptName;
        this.deptType = deptType;
    }

    public Integer getDeptNO()
    {
        return deptNO;
    }

    public void setDeptNO(Integer deptNO)
    {
        this.deptNO = deptNO;
    }

    public String getDeptName()
    {
        return deptName;
    }

    public void setDeptName(String deptName)
    {
        this.deptName = deptName;
    }

    public String getDeptType()
    {
        return deptType;
    }

    public void setDeptType(String deptType)
    {
        this.deptType = deptType;
    }

    @Override
    public String toString()
    {
        return "Dept{" +
                "deptNO=" + deptNO +
                ", deptName='" + deptName + '\'' +
                ", deptType='" + deptType + '\'' +
                '}';
    }
}
