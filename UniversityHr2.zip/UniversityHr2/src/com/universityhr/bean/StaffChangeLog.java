package com.universityhr.bean;

public class StaffChangeLog
{
    // 记录编号
    private Integer id;
    // 员工编号
    private Integer empID;
    // 员工姓名
    private String name;
    // 所在岗位
    private String post;
    // 变动类型
    private String type;
    // 变动日期
    private String date;

    public StaffChangeLog()
    {
    }

    public StaffChangeLog(Integer id, Integer empID, String name, String post, String type, String date)
    {
        this.id = id;
        this.empID = empID;
        this.name = name;
        this.post = post;
        this.type = type;
        this.date = date;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getEmpID()
    {
        return empID;
    }

    public void setEmpID(Integer empID)
    {
        this.empID = empID;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getPost()
    {
        return post;
    }

    public void setPost(String post)
    {
        this.post = post;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    @Override
    public String toString()
    {
        return "StaffChangeLog{" +
                "id=" + id +
                ", empID=" + empID +
                ", name='" + name + '\'' +
                ", post='" + post + '\'' +
                ", type='" + type + '\'' +
                ", date='" + date + '\'' +
                '}';
    }
}
