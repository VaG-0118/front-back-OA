package com.universityhr.service;

import com.universityhr.bean.Page;
import com.universityhr.bean.StaffChangeLog;


import java.util.List;

public interface StaffChangeLogService {

    //分页查询所有人员变动记录,输入页码号
    Page<StaffChangeLog> selectAllLog(Integer pageNo);
    //分页查询某一个员工的记录
    Page<StaffChangeLog> selectAllLogByEmpID(Integer pageNo, Integer empID);
    //分页通过类型查询记录
    Page<StaffChangeLog> selectAllLogByType(Integer pageNo, String type);
    //插入数据
    int add(StaffChangeLog staffChangeLog);
    //更新人员变动记录 通过id
    int update(StaffChangeLog staffChangeLog);
    //通过id删除人员变动信息记录
    int deleteById(Integer id);

    /**
     * 空实现
     * @param id
     * @return
     */
    //通过id查找记录
    StaffChangeLog selectOneById(Integer id);
    //查询所有记录
    List<StaffChangeLog> selectList();

}
