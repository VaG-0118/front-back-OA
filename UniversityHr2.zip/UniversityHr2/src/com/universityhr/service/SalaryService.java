package com.universityhr.service;



import com.universityhr.bean.Page;
import com.universityhr.bean.Salary;

import java.util.List;

public interface SalaryService {
    /**
     * 薪资管理：实现所有薪资信息的分页查询，对应页面money.jsp
     * 传入页数 查询数据
     * 查询出来的结果是很多条薪资
     */
    Page<Salary> selectPageSalary(Integer pageNo);
    /**
     * 通过员工的empno查询某个员工的多条薪资信息
     * 分页查询
     */
    Page<Salary> selectonebyempno(Integer pageNo,Integer empno);
    //统计某员工全部有多少条工资记录
    long selectCountByEmpID(int empID);
    //统计某员工本月有多少条工资记录
    long selectCountByEmpIDThisMonth(int empID);
    //统计某员工本年有多少条工资记录
    long selectCountByEmpIDThisYear(int empID);


    /**
     * 员工id查找某条记录
     */
    Salary selectOneById(Integer empID);
    //查询某员工全部的工资记录
    Page<Salary> selectEmpIDByPage(Integer pageNo, int empID);
    //查询某员工本月工资记录
    Page<Salary> selectthismonth(Integer pageNo,Integer empno);
    //统计某员工本年工资记录
    Page<Salary> selectthisyear(Integer pageNo,Integer empno);


    /**
     * 薪资管理：对某条薪资信息记录进行修改
     * 使用时需要传薪资等信息
     * 返回不为0成功 0 失败
     */
    int update(Integer id,Integer empID,Integer deptNO,String job,Double standardSalary,Double bonus,Double workSubsidy
            ,Double overtimepay,Double belate,Double leave,Double absent,Double socialInsurance,String date);

    /**
     * 按照id号对薪资信息记录进行删除
     * 返回不为0 成功 0 失败
     */
    int delete(Integer id);
    /**
     * 薪资管理：增加某薪资信息
     * 调用该方法参数依次是
     * 返回值不为0为成功 0为失败
     */
    int add(Integer empID,Integer deptNO,String job,Double standardSalary,Double bonus,Double workSubsidy
    ,Double overtimepay,Double belate,Double leave,Double absent,Double socialInsurance,String date);
    /**
     * 查询共有几条记录
     */
    long recordcount();


}
