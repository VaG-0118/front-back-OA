package com.universityhr.service;

import com.universityhr.bean.File;
import com.universityhr.bean.Page;

import java.util.List;

public interface FileService {
    /**
     * 按分页来查询所有的下发文件
     */
    Page<File> selecFilePage(Integer pageNo);

    /**
     * 按id查询某一个文件
     */
    File selectoneByid(Integer id);

    /**
     * 按name查询某一个文件
     */
    File selectoneByname(String filename);

    /**
     * 添加一个新文件
     */
    int add(File file);

    /**
     * 更新某条文件信息
     */
    int update(File file);

    /**
     * 按id删除某条文件信息
     */
    int deleteByid(Integer id);

    /**
     * 查询记录条数
     */
    long recordcount();

}
