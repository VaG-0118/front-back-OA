package com.universityhr.service;

import com.universityhr.bean.Applicant;
import com.universityhr.bean.Page;

public interface ApplicantService {
    //查询所有的应聘记录
    Page<Applicant> selectAllApplicant(Integer pageNo);
    //查询个人的应聘记录 按照name查询
    Page<Applicant> selectAllApplicantByName(Integer pageNo, String name);
    //查询状态应聘记录  通过已通过等状态
    Page<Applicant> selectAllApplicantByPassStatus(Integer pageNo, Integer passStatus);
    //插入entity
    int add(Applicant applicant);
    int changeStatusById(Integer id, Integer newStatus);
}
