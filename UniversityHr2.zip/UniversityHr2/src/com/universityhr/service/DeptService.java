package com.universityhr.service;



import com.universityhr.bean.Dept;
import com.universityhr.bean.Page;

import java.util.List;

public interface DeptService {
    /**
     * 部门管理：实现所有部门信息的分页查询，对应页面dept.jsp
     * 传入页数 查询数据
     * 通过部门类型查询数据,有两种方法 一种返回list 一种返回page
     */
    List<Dept> selectPageDept(Integer pageNo, String deptType);
    Page<Dept> selectDept(Integer pageNo, String deptType);
    Integer selectIdByName(String name);
    String selectNameById(Integer deptno);
    /**
     * 根据某个部门名称和部门类型实现分页查询(两个条件更精确)
     * deptName, deptType deptNO
     * 两种方法 返回值不同
     */
    List<Dept> selectPageByNameandType(Integer pageNo,String deptName, String deptType);
    Page<Dept> selectByNameandType(Integer pageNo,String deptName, String deptType);
    /**
     * 更改某个部门的信息
     */
    int update(Integer deptNo,String deptName,String deptType);

    /**
     * 按照id号对部门进行删除
     * 返回不为0 成功 0 失败
     */
    int delete(Integer deptNo);
    /**
     * 部门管理：增加某部门信息
     * 返回值不为0为成功 0为失败
     */
    int add(Integer deptNo,String deptName,String deptType);
    /**
     * 查询某个部门有几条记录
     */
    long recordcount(String deptType);

}
