package com.universityhr.service;

import com.universityhr.bean.Employee;
import com.universityhr.bean.Page;

import java.util.List;

public interface EmployeeService {
    /**
     * 员工管理：实现所有员工信息的分页查询，对应页面employee.jsp
     * 传入页数 查询数据
     * 查询出来的结果是employee1、employee2等员工
     * 这里有两种返回值方法
     */
    List<Employee> selectPageEmployee(Integer pageNo);
    Page<Employee> selectEmployee(Integer pageNo);
    /**
     * 查询所有员工
     */
    List<Employee> selectall();
    /**
     * 通过id查询某个具体员工信息
     */
    Employee selectonebyid(Integer id);
    /**
     * 通过名字查询某个具体员工信息
     * 考虑到重名 采用list列表，list列表中放的是各个员工实体
     */
     Employee selectonebyname(String name);
    /**
     * 员工管理：对某个员工信息进行修改
     * 使用时需要传员工i等信息
     * 返回不为0成功 0 失败
     */
    int update(Integer id,String name,Integer gender,String birthday,Integer politic_Status,Integer dept,String position,Integer status);
    //第二种更新方式 供user使用
    int updateEmployee(Employee employee);
    /**
     * 更改某个员工的状态（离职或在职）
     */
    int updatestatus(String name,Integer status);
    /**
     * 按照id号对员工进行删除
     * 返回不为0 成功 0 失败
     */
    int delete(Integer id);
    /**
     * 员工管理：增加某员工信息
     * 调用该方法参数依次是员工姓名、性别、生日、政治面貌、部门、职称、状态
     * 返回值不为0为成功 0为失败
     */
    int add(Integer id,String name,Integer gender,String birthday,Integer politic_Status,Integer dept,String position,Integer status);
    //第二种添加信息方式 供userupload使用
    int addEmployee(Employee employee);
    /**
     * 查询共有几条记录
     */
    long recordcount();
}
