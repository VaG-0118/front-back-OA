package com.universityhr.service;

import com.universityhr.bean.StaffUser;

public interface StaffUserService
{
    StaffUser login(String username, String password);

    boolean register(StaffUser user);
}
