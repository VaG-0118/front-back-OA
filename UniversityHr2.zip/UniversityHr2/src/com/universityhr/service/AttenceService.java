package com.universityhr.service;

import com.universityhr.bean.Attence;
import com.universityhr.bean.Page;

public interface AttenceService {
    /**
     *    userinfo中的内容
     */

    //查询 某具体员工的全部考勤记录
    Page<Attence> selectoneEmpByEmpIDByPage(Integer pageNo, int empID);

    //查询某个员工的本月考勤记录

    Page<Attence> selectAttenceByEmpIDThisMonth(Integer pageNo, int empID);
    //查询某个员工的本年的考勤记录
    Page<Attence> selectAttenceByEmpIDThisYear(Integer pageNo, int empID);
    //查询某个员工的全部考勤记录的条数
    long selectCountByEmpID(int empID);
    //查询某个员工的本月的考勤记录条数
    long selectCountByEmpIDThisMonth(int empID);
    //查询某个员工的本年的考勤记录条数
    long selectCountByEmpIDThisYear(int empID);
    /**
     * attence后台管理
     */
    //查询所有员工的考勤记录
    Page<Attence> selectAllAttenceByPage(Integer pageNo);
    //查询考勤记录
    int add(Attence attence);
    //更新考勤记录 按id更新
    int update(Attence attence);
    //删除考勤记录
    int deleteByid(Integer id);
    // 按empID、考勤类型查询次数
    long selectAttenceInfoByEmpID(Integer empID, String attenceInfo);

    //查询所有考勤记录
    long selectCount();

}
