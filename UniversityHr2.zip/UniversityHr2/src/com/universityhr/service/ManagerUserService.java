package com.universityhr.service;

import com.universityhr.bean.ManagerUser;

public interface ManagerUserService
{
    ManagerUser login(String username, String password);

    boolean register(ManagerUser user);
}
