package com.universityhr.service.impl;

import com.universityhr.bean.ManagerUser;
import com.universityhr.dao.ManagerUserDao;
import com.universityhr.dao.impl.ManagerUserDaoImpl;
import com.universityhr.service.ManagerUserService;

public class ManagerUserServiceImpl implements ManagerUserService
{
    ManagerUserDao userManagerDao = new ManagerUserDaoImpl();

    @Override
    public ManagerUser login(String username, String password)
    {
        ManagerUser user = userManagerDao.getUser(username);

        /**
         * 若user用户名和密码正确...验证，返回user.setPassword(null) return user;
         *
         */
        if (user != null && user.getPassword().equals(password))
        {
            user.setPassword(null);
            return user;
        }
        else
        {
            return null;
        }

    }

    @Override
    public boolean register(ManagerUser user)
    {
        /**
         * 实现用户的注册功能
         */
        final int result = userManagerDao.addUser(user);
        if (result == 1)
        {
            return true;
        }
        return false;
    }
}
