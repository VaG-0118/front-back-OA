package com.universityhr.service.impl;

import com.universityhr.bean.Employee;
import com.universityhr.bean.Page;
import com.universityhr.bean.Salary;
import com.universityhr.dao.SalaryDao;
import com.universityhr.dao.impl.SalaryDaoImpl;
import com.universityhr.service.SalaryService;

import java.util.List;

public class SalaryServiceImpl implements SalaryService {
    SalaryDao salaryDao=new SalaryDaoImpl();
    @Override
    public Page<Salary> selectPageSalary(Integer pageNo) {
        Page<Salary> page=new Page<>();
        page.setPageNo(pageNo);
        //分页查询;
        return salaryDao.selectAllSalaryByPage(page);
    }

    /**
     * 通过员工姓名查询薪资信息
     * @param
     * @return
     */
    @Override
    public Page<Salary> selectonebyempno(Integer pageNo,Integer empno) {
        Page<Salary> page=new Page<>();
        page.setPageNo(pageNo);
        return salaryDao.selectEmpIDByPage(page,empno);
    }

    @Override
    public long selectCountByEmpID(int empID) {
        return salaryDao.selectCountByEmpID(empID);
    }

    @Override
    public long selectCountByEmpIDThisMonth(int empID) {
        return salaryDao.selectCountByEmpIDThisMonth(empID);
    }

    @Override
    public long selectCountByEmpIDThisYear(int empID) {
        return salaryDao.selectCountByEmpIDThisYear(empID);
    }

    @Override
    public Salary selectOneById(Integer empID) {
        return salaryDao.selectOneById(empID);
    }

    @Override
    public Page<Salary> selectEmpIDByPage(Integer pageNo, int empID) {
        Page<Salary> page=new Page<>();
        page.setPageNo(pageNo);
        return salaryDao.selectEmpIDByPage(page,empID);
    }

    @Override
    public Page<Salary> selectthismonth(Integer pageNo,Integer empno) {
        Page<Salary> page=new Page<>();
        page.setPageNo(pageNo);
        return salaryDao.selectEmpIDByPageThisMonth(page,empno);
    }

    @Override
    public Page<Salary> selectthisyear(Integer pageNo,Integer empno) {
        Page<Salary> page=new Page<>();
        page.setPageNo(pageNo);
        return salaryDao.selectEmpIDByPageThisYear(page,empno);
    }


    @Override
    public int update(Integer id, Integer empID, Integer deptNO, String job, Double standardSalary,
                      Double bonus, Double workSubsidy, Double overtimepay,Double belate,
                      Double leave, Double absent, Double socialInsurance, String date) {
        Salary salary=new Salary();
        salary.setId(id);
        salary.setEmpID(empID);
        salary.setDeptNO(deptNO);
        salary.setJob(job);
        salary.setStandardSalary(standardSalary);
        salary.setBonus(bonus);
        salary.setWorkSubsidy(workSubsidy);
        salary.setOvertimePay(overtimepay);
        salary.setBelate(belate);
        salary.setLeave(leave);
        salary.setAbsent(absent);
        salary.setSocialInsurance(socialInsurance);//社保扣除
        salary.setDate(date);//考勤日期
        return salaryDao.update(salary);
    }


    @Override
    public int delete(Integer id) {
        return salaryDao.deleteById(id);
    }

    @Override
    public int add(Integer empID,Integer deptNO, String job, Double standardSalary, Double bonus, Double workSubsidy,Double overtimepay,Double belate, Double leave, Double absent, Double socialInsurance, String date) {
        Salary salary=new Salary();
        salary.setId(null);
        salary.setEmpID(empID);
        salary.setDeptNO(deptNO);
        salary.setJob(job);
        salary.setStandardSalary(standardSalary);
        salary.setBonus(bonus);
        salary.setWorkSubsidy(workSubsidy);
        salary.setOvertimePay(overtimepay);
        salary.setBelate(belate);
        salary.setLeave(leave);
        salary.setAbsent(absent);
        salary.setSocialInsurance(socialInsurance);//社保扣除
        salary.setDate(date);//考勤日期
        return salaryDao.insert(salary);
    }


    @Override
    public long recordcount() {
        return salaryDao.selectCount();
    }
}
