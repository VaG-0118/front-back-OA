package com.universityhr.service.impl;


import com.universityhr.bean.File;
import com.universityhr.bean.Page;
import com.universityhr.dao.FileDao;
import com.universityhr.dao.impl.FileDaoImpl;
import com.universityhr.service.FileService;

import java.util.List;

public class FileServiceImpl implements FileService {

    FileDaoImpl fileDao=new FileDaoImpl();
    @Override
    public Page<File> selecFilePage(Integer pageNo) {
        Page<File> page=new Page<>();
        page.setPageNo(pageNo);
        //分页查询;
        return fileDao.selectFileByPage(page);
    }

    public Page<File> selectFileByName(Page<File> page, String name)
    {
        return fileDao.selectFileByName(page, name);
    }

    @Override
    public File selectoneByid(Integer id) {
        return fileDao.selectOneById(id);
    }

    @Override
    public File selectoneByname(String filename) {
        return fileDao.selectFileName(filename);
    }

    @Override
    public int add(File file) {
        return fileDao.insert(file);
    }

    @Override
    public int update(File file) {
        return fileDao.update(file);
    }

    @Override
    public int deleteByid(Integer id) {
        return fileDao.deleteById(id);
    }

    @Override
    public long recordcount() {
        return fileDao.selectCount();
    }
}
