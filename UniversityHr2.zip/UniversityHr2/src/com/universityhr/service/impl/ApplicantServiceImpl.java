package com.universityhr.service.impl;

import com.universityhr.bean.Applicant;
import com.universityhr.bean.Page;
import com.universityhr.dao.ApplicantDao;
import com.universityhr.dao.impl.ApplicantDaoImpl;
import com.universityhr.service.ApplicantService;

public class ApplicantServiceImpl implements ApplicantService {
    ApplicantDao applicantDao=new ApplicantDaoImpl();
    @Override
    public Page<Applicant> selectAllApplicant(Integer pageNo) {
        Page<Applicant> page=new Page<>();
        page.setPageNo(pageNo);
        return applicantDao.selectAllApplicant(page);
    }

    @Override
    public Page<Applicant> selectAllApplicantByName(Integer pageNo, String name) {
        Page<Applicant> page=new Page<>();
        page.setPageNo(pageNo);
        return applicantDao.selectAllApplicantByName(page,name);
    }

    @Override
    public Page<Applicant> selectAllApplicantByPassStatus(Integer pageNo, Integer passStatus) {
        Page<Applicant> page=new Page<>();
        page.setPageNo(pageNo);
        return applicantDao.selectAllApplicantByPassStatus(page,passStatus);
    }

    @Override
    public int add(Applicant applicant) {
        return applicantDao.insert(applicant);
    }

    @Override
    public int changeStatusById(Integer id, Integer newStatus) {
        return applicantDao.changeStatusById(id,newStatus);
    }
}
