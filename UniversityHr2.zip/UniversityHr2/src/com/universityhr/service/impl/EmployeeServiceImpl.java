package com.universityhr.service.impl;


import com.sun.org.apache.regexp.internal.RE;
import com.universityhr.bean.Employee;
import com.universityhr.bean.Page;
import com.universityhr.dao.EmployeeDao;
import com.universityhr.dao.impl.EmployeeDaoImpl;
import com.universityhr.service.EmployeeService;

import java.util.EnumMap;
import java.util.List;

public class EmployeeServiceImpl implements EmployeeService {
    EmployeeDaoImpl employeeDao=new EmployeeDaoImpl();

    @Override
    public List<Employee> selectPageEmployee(Integer pageNo) {
        Page<Employee> page=new Page<>();
        page.setPageNo(pageNo);
        //分页查询;
        return employeeDao.selectByPage(page).getList();
    }

    @Override
    public Page<Employee> selectEmployee(Integer pageNo) {
        Page<Employee> page=new Page<>();
        page.setPageNo(pageNo);
        //分页查询;
        return employeeDao.selectByPage(page);
    }

    @Override
    public List<Employee> selectall() {
        List<Employee> list=employeeDao.selectList();
        return list;
    }

    @Override
    public Employee selectonebyid(Integer id) {
        final Employee employee = employeeDao.selectOneById(id);
        return employee;
    }

    @Override
    public Employee selectonebyname(String name) {
        Employee employee= employeeDao.selectByName(name);
        return employee;
    }


    @Override
    public int update(Integer id,String name,Integer gender,String birthday,Integer politic_Status,Integer dept,String position,Integer status) {
        Employee employee=new Employee();
        employee.setEmpID(id);
        employee.setEmpName(name);
        employee.setGender(gender);
        employee.setBirthday(birthday);
        employee.setPoliticalStatus(politic_Status);//员工的政治面貌 int类型 1代表共青团员、2代表...
        employee.setDeptNO(dept);//员工部门号
        employee.setEmpStatus(status);//员工离职或在职 int类型
        employee.setProfessionalTitle(position);//员工职称，string类型
        return employeeDao.update(employee);
    }

    @Override
    public int updateEmployee(Employee employee) {
        return employeeDao.update(employee);
    }

    @Override
    public int updatestatus(String name, Integer status) {
        return employeeDao.setEmpStatus(name,status);
    }

    @Override
    public int delete(Integer id) {
       return employeeDao.deleteById(id);
    }

    @Override
    public int add(Integer id,String name,Integer gender,String birthday,Integer politic_Status,Integer dept,String position,Integer status) {
        Employee employee=new Employee();
        employee.setEmpID(null);
        employee.setEmpName(name);
        employee.setGender(gender);
        employee.setBirthday(birthday);
        employee.setPoliticalStatus(politic_Status);//员工的政治面貌 int类型 1代表共青团员、2代表...
        employee.setDeptNO(dept);//员工部门号
        employee.setEmpStatus(status);//员工离职或在职 int类型
        employee.setProfessionalTitle(position);//员工职称，string类型
        return employeeDao.insert(employee);
    }

    @Override
    public int addEmployee(Employee employee) {
        return employeeDao.insert(employee);
    }

    @Override
    public long recordcount() {
        return employeeDao.selectCount();
    }

}
