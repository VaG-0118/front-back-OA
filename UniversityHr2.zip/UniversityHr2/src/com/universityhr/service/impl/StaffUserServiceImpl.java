package com.universityhr.service.impl;

import com.universityhr.bean.StaffUser;
import com.universityhr.dao.StaffUserDao;
import com.universityhr.dao.impl.StaffUserDaoImpl;
import com.universityhr.service.StaffUserService;

public class StaffUserServiceImpl implements StaffUserService
{
    StaffUserDao userDao = new StaffUserDaoImpl();

    @Override
    public StaffUser login(String username, String password)
    {
        //利用userdao的getuser返回的user对象
        StaffUser user = userDao.getUser(username);

        /**
         * 若user用户名和密码正确...验证，返回user.setPassword(null) return user;
         *
         */
        if (user != null && user.getPassword().equals(password))
        {
            user.setPassword(null);
            return user;
        }
        else
        {
            return null;
        }
    }

    @Override
    public boolean register(StaffUser user)
    {
        /**
         * 实现用户的注册功能
         */
        final int result = userDao.addUser(user);
        if (result == 1)
        {
            return true;
        }
        return false;
    }
}
