package com.universityhr.service.impl;

import com.universityhr.bean.Dept;
import com.universityhr.bean.Page;
import com.universityhr.dao.DeptDao;
import com.universityhr.dao.impl.DeptDaoImpl;
import com.universityhr.service.DeptService;

import java.util.List;

public class DeptServiceImpl implements DeptService {
    DeptDaoImpl deptDao=new DeptDaoImpl();
    @Override
    public List<Dept> selectPageDept(Integer pageNo, String deptType) {
        Page<Dept> page=new Page<>();
        page.setPageNo(pageNo);
        //分页查询 根据某一类型查询
        return deptDao.selectAllByTypeByPage(page,deptType).getList();
    }

    @Override
    public Page<Dept> selectDept(Integer pageNo, String deptType) {
        Page<Dept> page=new Page<>();
        page.setPageNo(pageNo);
        //分页查询 根据某一类型查询
        return deptDao.selectAllByTypeByPage(page,deptType);
    }

    @Override
    public Integer selectIdByName(String name) {
        return deptDao.selectIdByName(name);
    }

    @Override
    public String selectNameById(Integer deptno) {
        return deptDao.selectNameById(deptno);
    }

    @Override
    public List<Dept> selectPageByNameandType(Integer pageNo, String deptName, String deptType) {
        Page<Dept> page=new Page<>();
        page.setPageNo(pageNo);
        //分页查询 根据某一部门类型中的某一个部门名称查询
        return deptDao.selectDeptNameAndTypeByPage(page,deptName,deptType).getList();
    }

    @Override
    public Page<Dept> selectByNameandType(Integer pageNo, String deptName, String deptType) {
        Page<Dept> page=new Page<>();
        page.setPageNo(pageNo);
        //分页查询 根据某一部门类型中的某一个部门名称查询
        return deptDao.selectDeptNameAndTypeByPage(page,deptName,deptType);
    }

    @Override
    public int update(Integer deptNo, String deptName, String deptType) {
        Dept dept=new Dept(deptNo,deptName,deptType);
        return deptDao.update(dept);
    }

    @Override
    public int delete(Integer deptNo) {
        return deptDao.deleteById(deptNo);
    }

    @Override
    public int add(Integer deptNo, String deptName, String deptType) {
        Dept dept=new Dept(deptNo,deptName,deptType);
        return deptDao.insert(dept);
    }

    @Override
    public long recordcount(String deptType) {
        return deptDao.selectCount(deptType);
    }
}
