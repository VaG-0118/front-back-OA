package com.universityhr.service.impl;

import com.universityhr.bean.Attence;
import com.universityhr.bean.Page;
import com.universityhr.dao.AttenceDao;
import com.universityhr.dao.impl.AttenceDaoImpl;
import com.universityhr.service.AttenceService;


public class AttenceServiceImpl implements AttenceService {
    AttenceDao attenceDao=new AttenceDaoImpl();
    @Override
    public Page<Attence> selectoneEmpByEmpIDByPage(Integer pageNo, int empID) {
        Page<Attence> page=new Page<>();
        page.setPageNo(pageNo);
        return attenceDao.selectAllAttenceByEmpIDByPage(page,empID);
    }

    @Override
    public Page<Attence> selectAttenceByEmpIDThisMonth(Integer pageNo, int empID) {
        Page<Attence> page=new Page<>();
        page.setPageNo(pageNo);
        return attenceDao.selectAttenceByEmpIDThisMonth(page,empID);

    }

    @Override
    public Page<Attence> selectAttenceByEmpIDThisYear(Integer pageNo, int empID) {
        Page<Attence> page=new Page<>();
        page.setPageNo(pageNo);
        return attenceDao.selectAttenceByEmpIDThisYear(page,empID);
    }

    @Override
    public long selectCountByEmpID(int empID) {
        return attenceDao.selectCountByEmpID(empID);
    }

    @Override
    public long selectCountByEmpIDThisMonth(int empID) {
        return attenceDao.selectCountByEmpIDThisMonth(empID);
    }

    @Override
    public long selectCountByEmpIDThisYear(int empID) {
        return attenceDao.selectCountByEmpIDThisYear(empID);
    }

    @Override
    public Page<Attence> selectAllAttenceByPage(Integer pageNo) {
        Page<Attence> page=new Page<>();
        page.setPageNo(pageNo);
        return attenceDao.selectAllAttenceByPage(page);
    }

    @Override
    public int add(Attence attence) {
        return attenceDao.insert(attence);
    }

    @Override
    public int update(Attence attence) {
        return attenceDao.update(attence);
    }

    @Override
    public int deleteByid(Integer id) {
        return attenceDao.deleteById(id);
    }

    @Override
    public long selectAttenceInfoByEmpID(Integer empID, String attenceInfo) {
        return attenceDao.selectAttenceInfoByEmpID(empID,attenceInfo);
    }

    @Override
    public long selectCount() {
        return attenceDao.selectCount();
    }
}
