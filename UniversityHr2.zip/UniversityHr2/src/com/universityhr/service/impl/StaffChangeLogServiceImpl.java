package com.universityhr.service.impl;

import com.universityhr.bean.Page;
import com.universityhr.bean.StaffChangeLog;
import com.universityhr.dao.StaffChangeLogDao;
import com.universityhr.dao.impl.StaffChangeLogDaoImpl;
import com.universityhr.service.StaffChangeLogService;

import java.util.List;

public class StaffChangeLogServiceImpl implements StaffChangeLogService {
    StaffChangeLogDaoImpl staffChangeLogDao=new StaffChangeLogDaoImpl();
    @Override
    public Page<StaffChangeLog> selectAllLog(Integer pageNo) {
        Page<StaffChangeLog> page=new Page<>();
        page.setPageNo(pageNo);
        return staffChangeLogDao.selectAllLog(page);
    }

    @Override
    public Page<StaffChangeLog> selectAllLogByEmpID(Integer pageNo, Integer empID) {
        Page<StaffChangeLog> page=new Page<>();
        page.setPageNo(pageNo);
        return staffChangeLogDao.selectAllLogByEmpID(page,empID);
    }

    @Override
    public Page<StaffChangeLog> selectAllLogByType(Integer pageNo, String type) {
        Page<StaffChangeLog> page=new Page<>();
        page.setPageNo(pageNo);
        return staffChangeLogDao.selectAllLogByType(page,type);
    }

    @Override
    public int add(StaffChangeLog staffChangeLog) {
        return staffChangeLogDao.insert(staffChangeLog);
    }

    @Override
    public int update(StaffChangeLog staffChangeLog) {
        return staffChangeLogDao.update(staffChangeLog);
    }

    @Override
    public int deleteById(Integer id) {
        return staffChangeLogDao.deleteById(id);
    }
    //未实现
    @Override
    public StaffChangeLog selectOneById(Integer id) {
        return staffChangeLogDao.selectOneById(id);
    }
    //未实现
    @Override
    public List<StaffChangeLog> selectList() {
        return staffChangeLogDao.selectList();
    }
}
