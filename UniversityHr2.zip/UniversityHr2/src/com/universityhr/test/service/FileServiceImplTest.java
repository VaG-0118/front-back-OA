package com.universityhr.test.service;

import com.universityhr.bean.File;
import com.universityhr.service.FileService;
import com.universityhr.service.impl.FileServiceImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class FileServiceImplTest {
    FileService fileService=new FileServiceImpl();

    @Test
    public void selecFilePage() {
        System.out.println(fileService.selecFilePage(1));
    }

    @Test
    public void selectoneByid() {
        System.out.println(fileService.selectoneByid(1));
    }

    @Test
    public void selectoneByname() {
        System.out.println(fileService.selectoneByname("国庆假期教职工临时通知"));
    }

    @Test
    public void add() {
        File file=new File();
        file.setFileName("国庆假期教职工临时通知");
        file.setAuthor("人事部");
        file.setFileType("临时通知文件");
        file.setDate("2020-10-2");
        System.out.println(fileService.add(file));
    }

    @Test
    public void update() {
        File file=new File();
        file.setId(1);
        file.setFileName("国庆假期教职工临时通知");
        file.setAuthor("人事部");
        file.setFileType("临时通知文件");
        file.setDate("2020-10-5");
        System.out.println(fileService.update(file));
    }

    @Test
    public void deleteByid() {
        System.out.println(fileService.deleteByid(1));
    }

    @Test
    public void recordcount() {
        System.out.println(fileService.recordcount());
    }
}