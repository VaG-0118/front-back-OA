package com.universityhr.test.service;

import com.universityhr.service.DeptService;
import com.universityhr.service.impl.DeptServiceImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class DeptServiceImplTest {
    DeptService deptService=new DeptServiceImpl();

    @Test
    public void selectPageDept() {
        System.out.println(deptService.selectPageDept(1, "科研机构"));
    }

    @Test
    public void selectPageByNameandType() {
        System.out.println(deptService.selectPageByNameandType(1, "研究院", "科研机构"));
    }

    @Test
    public void update() {
        System.out.println(deptService.update(3, "研究院", "科研机构"));
    }

    @Test
    public void delete() {
        System.out.println(deptService.delete(3));
    }

    @Test
    public void add() {
        System.out.println(deptService.add(3, "科学研究院", "科研机构"));

    }
    @Test
    public void recordcount() {
        System.out.println(deptService.recordcount("科研机构"));

    }
}