package com.universityhr.test.service;

import com.universityhr.bean.Attence;
import com.universityhr.service.AttenceService;
import com.universityhr.service.impl.AttenceServiceImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class AttenceServiceImplTest {
    AttenceService attenceService=new AttenceServiceImpl();
    @Test
    public void selectoneEmpByEmpIDByPage() {
        System.out.println(attenceService.selectoneEmpByEmpIDByPage(1,1));
    }

    @Test
    public void selectAttenceByEmpIDThisMonth() {
        System.out.println(attenceService.selectAttenceByEmpIDThisMonth(1,1));
    }

    @Test
    public void selectAttenceByEmpIDThisYear() {
        System.out.println(attenceService.selectAttenceByEmpIDThisYear(1,1));
    }

    @Test
    public void selectCountByEmpID() {
        System.out.println(attenceService.selectCountByEmpID(1));
    }

    @Test
    public void selectCountByEmpIDThisMonth() {
        System.out.println(attenceService.selectCountByEmpIDThisMonth(1));
    }

    @Test
    public void selectCountByEmpIDThisYear() {
        System.out.println(attenceService.selectCountByEmpIDThisYear(1));
    }

    @Test
    public void selectAllAttenceByPage() {
        System.out.println(attenceService.selectAllAttenceByPage(1));
    }

    @Test
    public void add() {
        Attence attence=new Attence();
        attence.setId(1);
        attence.setEmpID(1);
        attence.setEmpName("张三");
        attence.setDeptName("人事部");
        attence.setEmpStatus(1);
        attence.setAttenceInfo("迟到");
        attence.setDate("2020-2-2");
        System.out.println(attenceService.add(attence));
    }

    @Test
    public void update() {
        Attence attence=new Attence();
        attence.setId(2);
        attence.setEmpName("张三");
        attence.setDeptName("人事部");
        attence.setAttenceInfo("早退");
        attence.setDate("2020-2-2");
        System.out.println(attenceService.update(attence));
    }

    @Test
    public void deleteByid() {
        System.out.println(attenceService.deleteByid(1));
    }

    @Test
    public void selectAttenceInfoByEmpID() {
        System.out.println(attenceService.selectAttenceInfoByEmpID(1,"迟到"));
    }

    @Test
    public void selectCount() {
        System.out.println(attenceService.selectCount());
    }
}