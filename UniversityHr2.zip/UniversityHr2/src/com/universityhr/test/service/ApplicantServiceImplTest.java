package com.universityhr.test.service;

import com.universityhr.bean.Applicant;
import com.universityhr.service.ApplicantService;
import com.universityhr.service.impl.ApplicantServiceImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class ApplicantServiceImplTest {
    ApplicantService applicantService=new ApplicantServiceImpl();

    @Test
    public void selectAllApplicant() {
        System.out.println(applicantService.selectAllApplicant(1));
    }

    @Test
    public void selectAllApplicantByName() {
        System.out.println(applicantService.selectAllApplicantByName(1,"zhangsan"));
    }

    @Test
    public void selectAllApplicantByPassStatus() {
        System.out.println(applicantService.selectAllApplicantByPassStatus(1,0));
    }

    @Test
    public void add() {
        Applicant applicant=new Applicant();
        applicant.setPersonName("zhangsan");
        applicant.setPassStatus(0);
        applicant.setGender(1);
        applicant.setPurposePost("大学英语老师");
        applicant.setEducation("本科");
        applicant.setPurposeSalary(2000);
        applicant.setWorkExperience(1);
        applicant.setTelephone("122346352");
        applicant.setSubmitDate("2020-2-2");
        System.out.println(applicantService.add(applicant));
    }
}