package com.universityhr.test.service;

import com.universityhr.bean.ManagerUser;
import com.universityhr.service.ManagerUserService;
import com.universityhr.service.impl.ManagerUserServiceImpl;
import org.junit.Test;

public class ManagerStaffUserServiceImplTest
{
    ManagerUserService managerUserService =new ManagerUserServiceImpl();
    @Test
    public void login() {
        System.out.println(managerUserService.login("zhangsan","123456789"));
    }

    @Test
    public void register() {
        ManagerUser user=new ManagerUser("wangwu","11111111","wngwu@qq.com");
        System.out.println(managerUserService.register(user));
    }
}