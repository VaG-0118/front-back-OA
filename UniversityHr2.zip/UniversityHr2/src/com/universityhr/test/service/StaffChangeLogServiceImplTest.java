package com.universityhr.test.service;

import com.universityhr.bean.StaffChangeLog;
import com.universityhr.service.StaffChangeLogService;
import com.universityhr.service.impl.StaffChangeLogServiceImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class StaffChangeLogServiceImplTest {
    StaffChangeLogService staffChangeLogService=new StaffChangeLogServiceImpl();

    @Test
    public void selectAllLog() {
        System.out.println(staffChangeLogService.selectAllLog(1));
    }

    @Test
    public void selectAllLogByEmpID() {
        System.out.println(staffChangeLogService.selectAllLogByEmpID(1,1));
    }

    @Test
    public void selectAllLogByType() {
        System.out.println(staffChangeLogService.selectAllLogByType(1,"离职"));
    }

    @Test
    public void add() {
        StaffChangeLog staffChangeLog=new StaffChangeLog();
        staffChangeLog.setId(1);
        staffChangeLog.setEmpID(1);
        staffChangeLog.setName("zhangsan");
        staffChangeLog.setType("在职");
        staffChangeLog.setPost("老师");
        staffChangeLog.setDate("2020-2-2");
        System.out.println(staffChangeLogService.add(staffChangeLog));
    }

    @Test
    public void update() {
        StaffChangeLog staffChangeLog=new StaffChangeLog();
        staffChangeLog.setId(1);
        staffChangeLog.setEmpID(1);
        staffChangeLog.setName("zhangsan");
        staffChangeLog.setType("离职");
        staffChangeLog.setPost("老师");
        staffChangeLog.setDate("2020-2-2");
        System.out.println(staffChangeLogService.update(staffChangeLog));
    }

    @Test
    public void deleteById() {
        System.out.println(staffChangeLogService.deleteById(1));
    }

    @Test
    public void selectOneById() {
    }

    @Test
    public void selectList() {
    }
}