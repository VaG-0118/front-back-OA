package com.universityhr.test.service;

import com.universityhr.service.EmployeeService;
import com.universityhr.service.impl.EmployeeServiceImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class EmployeeServiceImplTest {
    EmployeeService employeeService=new EmployeeServiceImpl();

    @Test
    public void selectPageEmployee() {
        System.out.println(employeeService.selectPageEmployee(1));
    }

    @Test
    public void selectall() {
        System.out.println(employeeService.selectall());
    }

    @Test
    public void selectonebyid() {
        System.out.println(employeeService.selectonebyid(2));
    }

    @Test
    public void selectonebyname() {
        System.out.println(employeeService.selectonebyname("zhangsan"));
        System.out.println(employeeService.selectonebyname("waawa"));
    }

    @Test
    public void update() {
        System.out.println(employeeService.update(4, "zhangsan", 1, "2000-2-2", 1, 1, "党员", 0));

    }

    @Test
    public void updatestatus() {
        System.out.println(employeeService.updatestatus("zhaoliu", 1));
    }

    @Test
    public void delete() {
        System.out.println(employeeService.delete(5));
    }

    @Test
    public void add() {
        System.out.println(employeeService.add(4, "zhaoliu", 1, "2000-2-2", 1, 1, "党员", 0));

    }

    @Test
    public void recordcount() {
        System.out.println(employeeService.recordcount());
    }
}