package com.universityhr.test.service;

import com.universityhr.service.SalaryService;
import com.universityhr.service.impl.SalaryServiceImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class SalaryServiceImplTest {
    SalaryService salaryService=new SalaryServiceImpl();

    @Test
    public void selectPageSalary() {
        System.out.println(salaryService.selectPageSalary(1));
    }

    @Test
    public void selectonebyempno() {
        System.out.println(salaryService.selectonebyempno(1, 3));
    }

    @Test
    public void selectthismonth() {
        System.out.println(salaryService.selectthismonth(1,3));
    }

    @Test
    public void selectthisyear() {
        System.out.println(salaryService.selectthisyear(1,3));
    }

    @Test
    public void update() {
        System.out.println(salaryService.update(1, 4, 3, "老师", 3000.0, 2000.0, 100.0, 100.0,2.0, 3.0, 10.0, 100.0, "2000-2-2"));
    }

    @Test
    public void delete() {
        System.out.println(salaryService.delete(1));
    }

    @Test
    public void add() {
        System.out.println(salaryService.add(4, 2, "老师", 2000.0, 1000.0, 100.0, 100.0,2.0, 3.0, 10.0, 100.0, "2000-2-2"));


    }

    @Test
    public void recordcount() {
        System.out.println(salaryService.recordcount());
    }
}