package com.universityhr.test.service;

import com.universityhr.bean.StaffUser;
import com.universityhr.service.StaffUserService;
import com.universityhr.service.impl.StaffUserServiceImpl;
import org.junit.Test;

public class StaffUserServiceImplTest
{
    StaffUserService staffUserService =new StaffUserServiceImpl();
    @Test
    public void login() {

        System.out.println(staffUserService.login("zhangsan","123456789"));
    }

    @Test
    public void register() {
        StaffUser user=new StaffUser("wangwu","11111111","wngwu@qq.com");
        System.out.println(staffUserService.register(user));
    }
}