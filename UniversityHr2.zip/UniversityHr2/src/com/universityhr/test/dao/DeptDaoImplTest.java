package com.universityhr.test.dao;

import com.universityhr.bean.Dept;
import com.universityhr.bean.Page;
import com.universityhr.dao.DeptDao;
import com.universityhr.dao.impl.DeptDaoImpl;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class DeptDaoImplTest
{
    DeptDaoImpl deptDao = new DeptDaoImpl();

    @Test
    public void selectDeptNameAndTypeByPage()
    {
        Page<Dept> page = new Page<Dept>();
        page.setPageSize(2);
        page.setPageSize(2);
        page = deptDao.selectDeptNameAndTypeByPage(page, "教务处", "行政机构");
        Assert.assertNotNull(page);
        System.out.println(page.getList());
    }

    @Test
    public void selectAllByTypeByPage()
    {
        Page<Dept> page = new Page<Dept>();
        page.setPageNo(2);
        page.setPageSize(2);
        page = deptDao.selectAllByTypeByPage(page,  "行政机构");
        Assert.assertNotNull(page);
        System.out.println(page.getList());
    }

    @Test
    public void insert()
    {
        Dept dept = new Dept(4, "宣传部", "党委机构");
        int count = deptDao.insert(dept);
        Assert.assertEquals(count, 1);
    }

    @Test
    public void update()
    {
        Dept dept = new Dept(4, "宣传部", "党委机构");
        int count = deptDao.update(dept);
        Assert.assertEquals(count, 1);
    }

    @Test
    public void deleteById()
    {
        int count = deptDao.deleteById(4);
        Assert.assertEquals(count, 1);
    }

    @Test
    public void selectOneById()
    {
    }

    @Test
    public void selectList()
    {
    }
}