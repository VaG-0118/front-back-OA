package com.universityhr.test.dao;

import com.universityhr.bean.File;
import com.universityhr.bean.Page;
import com.universityhr.dao.impl.FileDaoImpl;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class FileDaoImplTest
{
    FileDaoImpl fileDao = new FileDaoImpl();

    @Test
    public void insert()
    {
        File file = new File(null, "第一次党代会文件", "记录", "卫子涵", "2020-5-3");
        int count = fileDao.insert(file);
        Assert.assertEquals(count, 1);
    }

    @Test
    public void update()
    {
        File file = new File(1, "第一次党代会文件", "记录", "卫子涵", "2020-5-4");
        int count = fileDao.update(file);
        Assert.assertEquals(count, 1);
    }

    @Test
    public void deleteById()
    {
        int count = fileDao.deleteById(2);
        Assert.assertEquals(count, 1);
    }

    @Test
    public void selectOneById()
    {
        File file = null;
        file = fileDao.selectOneById(1);
        Assert.assertNotNull(file);
        System.out.println(file);
    }

    @Test
    public void selectList()
    {
    }

    @Test
    public void selectFileByPage()
    {
        Page<File> page = new Page<>();
        page.setPageNo(2);
        page.setPageSize(2);
        page = fileDao.selectFileByPage(page);
        Assert.assertNotNull(page);
        System.out.println(page.getList());
    }

    @Test
    public void selectCount()
    {
        int count = (int) fileDao.selectCount();
        Assert.assertEquals(count, 3);
    }

    @Test
    public void selectFileName()
    {
        File file = fileDao.selectFileName("第一次党代会文件");
        Assert.assertNotNull(file);
        System.out.println(file);
    }
}