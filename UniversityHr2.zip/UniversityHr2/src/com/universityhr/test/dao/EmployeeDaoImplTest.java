package com.universityhr.test.dao;

import com.universityhr.bean.Employee;
import com.universityhr.bean.Page;
import com.universityhr.dao.impl.EmployeeDaoImpl;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

public class EmployeeDaoImplTest
{
    EmployeeDaoImpl employeeDao = new EmployeeDaoImpl();

    @Test
    public void insert()
    {

    }


    @Test
    public void update()
    {

    }

    @Test
    public void deleteById()
    {
        int count = employeeDao.deleteById(2);
        Assert.assertEquals(count, 1);
    }

    @Test
    public void selectOneById()
    {
        Employee employee = null;
        employee = employeeDao.selectOneById(3);
        Assert.assertNotNull(employee);
        System.out.println(employee);
    }

    @Test
    public void selectList()
    {
        List<Employee> list = null;
        list = employeeDao.selectList();
        Assert.assertNotNull(list);
    }

    @Test
    public void selectByName()
    {
        Employee employee = null;
        employee = employeeDao.selectByName("wzh");
        Assert.assertNotNull(employee);
        System.out.println(employee);
    }


    @Test
    public void setEmpStatus()
    {
        int count = employeeDao.setEmpStatus("wzh", 1);
        Assert.assertEquals(count, 1);
    }

    @Test
    public void selectByPage()
    {
        Page<Employee> page = new Page<>();
        page.setPageNo(2);
        Page<Employee> empPage = employeeDao.selectByPage(page);
        System.out.println(empPage.getList().size());
        Assert.assertNotNull(empPage);
        System.out.println(empPage.getList());
    }

    @Test
    public void selectCount()
    {
        System.out.println(employeeDao.selectCount());

    }


}