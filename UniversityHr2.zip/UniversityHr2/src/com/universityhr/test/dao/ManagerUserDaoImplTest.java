package com.universityhr.test.dao;

import com.sun.tools.internal.xjc.reader.xmlschema.bindinfo.BIConversion;
import com.universityhr.bean.ManagerUser;
import com.universityhr.dao.ManagerUserDao;
import com.universityhr.dao.impl.ManagerUserDaoImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class ManagerUserDaoImplTest {
    ManagerUserDao managerUserDao=new ManagerUserDaoImpl();

    @Test
    public void getUser() {
        System.out.println(managerUserDao.getUser("zhangsan"));
    }

    @Test
    public void saveUser() {
        ManagerUser managerUser=new ManagerUser("zhangsan","12345678","lisi@qq.com");
        System.out.println(managerUserDao.saveUser(managerUser));
    }

    @Test
    public void addUser() {
        ManagerUser managerUser=new ManagerUser("lisi","12345678","lisi@qq.com");
        System.out.println(managerUserDao.addUser(managerUser));
    }
}