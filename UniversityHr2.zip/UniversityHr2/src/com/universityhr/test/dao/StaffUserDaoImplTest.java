package com.universityhr.test.dao;


import com.universityhr.bean.ManagerUser;
import com.universityhr.bean.StaffUser;
import com.universityhr.dao.StaffUserDao;
import com.universityhr.dao.impl.ManagerUserDaoImpl;
import com.universityhr.dao.impl.StaffUserDaoImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class StaffUserDaoImplTest {
    StaffUserDao staffUserDao=new StaffUserDaoImpl();

    @Test
    public void getUser() {
        System.out.println(staffUserDao.getUser("zhangsan"));

    }

    @Test
    public void saveUser() {
        StaffUser staffUser=new StaffUser("lisi","12345677","lisi@qq.com");
        System.out.println(staffUserDao.saveUser(staffUser));
    }

    @Test
    public void addUser() {
        StaffUser staffUser=new StaffUser("lisi","12345678","lisi@qq.com");
        System.out.println(staffUserDao.addUser(staffUser));
    }
}