package com.universityhr.servlet;
import com.universityhr.bean.*;
import com.universityhr.service.DeptService;
import com.universityhr.service.EmployeeService;
import com.universityhr.service.SalaryService;
import com.universityhr.service.impl.DeptServiceImpl;
import com.universityhr.service.impl.EmployeeServiceImpl;
import com.universityhr.service.impl.SalaryServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/SalaryServlet")
public class SalaryServlet extends BaseServlet{
    private static final long serialVersionUID = 1L;
    SalaryService salaryService=new SalaryServiceImpl();
    EmployeeService employeeService=new EmployeeServiceImpl();
    DeptService deptService=new DeptServiceImpl();
    //分页
    protected void selectPageSalary(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pageNo=request.getParameter("pageNo");
        int defaultPageNo=1;
        try {
            defaultPageNo = Integer.parseInt(pageNo);
        } catch (Exception e) {
            System.out.println("错误");
        }
        Page<Salary> page=salaryService.selectPageSalary(defaultPageNo);
        request.setAttribute("salaryy", page.getList());
        request.setAttribute("count", page.getTotalPageNo());
        request.getRequestDispatcher("/pages/manager/salary.jsp").forward(request, response);
    }
    //增加
    protected void salaryupload(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("addmoney");
        request.setCharacterEncoding("UTF-8");
        Salary salary= new Salary();
        final String deptName = request.getParameter("deptName");
        salary.setEmpName(deptName);
        Employee employee = employeeService.selectonebyname(request.getParameter("empName"));
        int deptNO=deptService.selectIdByName(request.getParameter("deptName"));
        int empID=employee.getEmpID();
        final String job=request.getParameter("job");
        final Double standardSalary=(Double.parseDouble(request.getParameter("standardSalary")));
        final Double bonus=(Double.parseDouble(request.getParameter("bonus")));
        final Double workSubsidy=(Double.parseDouble(request.getParameter("workSubsidy")));
        final Double overtimePay=(Double.parseDouble(request.getParameter("overtimePay")));
        final Double belate=(Double.parseDouble(request.getParameter("belate")));
        final Double leave=(Double.parseDouble(request.getParameter("leave")));
        final Double absent=(Double.parseDouble(request.getParameter("absent")));
        final Double socialInsurance=(Double.parseDouble(request.getParameter("socialInsurance")));
        final String date=(request.getParameter("date"));
        salaryService.add(empID,deptNO,job,standardSalary,bonus,workSubsidy,overtimePay,belate,leave,absent,socialInsurance,date);
        request.getRequestDispatcher("SalaryServlet?methodName=selectPageSalary").forward(request,response);


    }

    //获取某员工全部
    protected void salaryall(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Salary> salarys = salaryService.selectEmpIDByPage(1,Integer.parseInt(request.getParameter("EmpID"))).getList();
        Salary salary=salarys.get(0);
        request.setAttribute("salary",salary);
        request.getRequestDispatcher("/pages/manager/addmoney.jsp").forward(request,response);

    }
    protected void salaryedit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        Salary salary=new Salary();
//        salary.setEmpName(request.getParameter("empName"));
//        Employee employee=employeeService.selectonebyname(salary.getDeptName());
//        salary.setEmpID(employee.getEmpID());
//        salary.setJob(request.getParameter("job"));
//        salary.setStandardSalary(Double.parseDouble(request.getParameter("standardSalary")));
//        salary.setBonus(Double.parseDouble(request.getParameter("bonus")));
//        salary.setWorkSubsidy(Double.parseDouble(request.getParameter("workSubsidy")));
//        salary.setOvertimePay(Double.parseDouble(request.getParameter("overtimePay")));
//        salary.setBelate(Double.parseDouble(request.getParameter("belate")));
//        salary.setLeave(Double.parseDouble(request.getParameter("leave")));
//        salary.setAbsent(Double.parseDouble(request.getParameter("absent")));
//        salary.setSocialInsurance(Double.parseDouble(request.getParameter("socialInsurance")));
//        salary.setDate(request.getParameter("date"));
//        String deptname=deptService.selectNameById(employee.getDeptNO());
//        salary.setDeptName(deptname);
        Salary salary= new Salary();
        final String deptName = request.getParameter("deptName");
        salary.setEmpName(deptName);
        Employee employee = employeeService.selectonebyname(request.getParameter("empName"));
        Integer deptNO=Integer.valueOf(request.getParameter("deptNO"));
        int empID=employee.getEmpID();
        final String job=request.getParameter("job");
        final Double standardSalary=(Double.parseDouble(request.getParameter("standardSalary")));
        final Double bonus=(Double.parseDouble(request.getParameter("bonus")));
        final Double workSubsidy=(Double.parseDouble(request.getParameter("workSubsidy")));
        final Double overtimePay=(Double.parseDouble(request.getParameter("overtimePay")));
        final Double belate=(Double.parseDouble(request.getParameter("belate")));
        final Double leave=(Double.parseDouble(request.getParameter("leave")));
        final Double absent=(Double.parseDouble(request.getParameter("absent")));
        final Double socialInsurance=(Double.parseDouble(request.getParameter("socialInsurance")));
        final String date=(request.getParameter("date"));
        salaryService.update(null,empID,deptNO,job,standardSalary,bonus,workSubsidy,overtimePay,belate,leave,absent,socialInsurance,date);
        HttpSession session=request.getSession();
        session.removeAttribute("empID");
        session.removeAttribute("deptNO");
        session.removeAttribute("job");
        session.removeAttribute("standardSalary");
        session.removeAttribute("bonus");
        session.removeAttribute("workSubsidy");
        session.removeAttribute("overtimePay");
        session.removeAttribute("belate");
        session.removeAttribute("leave");
        session.removeAttribute("absent");
        session.removeAttribute("socialInsurance");
        session.removeAttribute("date");
        request.getRequestDispatcher("SalaryServlet?methodName=selectPageSalary").forward(request,response);

    }

    protected void salaryselectone(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pageNo=request.getParameter("pageNo");
        int defaultPageNo=1;
        try {
            defaultPageNo = Integer.parseInt(pageNo);
        } catch (Exception e) {
            System.out.println("错误");
        }
        int id=Integer.parseInt(request.getParameter("empno"));
        List<Salary> salarys =salaryService.selectonebyempno(defaultPageNo,id).getList();
        request.setAttribute("salarys", salarys);
        request.getRequestDispatcher("pages/manager/salary.jsp").forward(request,response);

    }
    protected void salarydelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        int id=Integer.valueOf(request.getParameter("id"));
        salaryService.delete(id);
        response.sendRedirect(request.getContextPath()+"/SalaryServlet?methodName=selectPageSalary");
    }


}
