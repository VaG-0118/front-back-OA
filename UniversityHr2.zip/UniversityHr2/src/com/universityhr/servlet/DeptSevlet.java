package com.universityhr.servlet;

import com.universityhr.bean.Dept;
import com.universityhr.bean.Page;
import com.universityhr.service.DeptService;
import com.universityhr.service.impl.DeptServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/DeptServlet")
public class DeptSevlet extends BaseServlet {
    private DeptService deptService = new DeptServiceImpl();

    //查询
    protected void selectDeptOne(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("selectDeptOne");
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        Integer deptNo = Integer.parseInt(request.getParameter("deptNo"));
        final String deptName = request.getParameter("deptName");
        final String deptType = request.getParameter("deptType");
        session.setAttribute("deptNo",deptNo);
        session.setAttribute("deptName",deptName);
        session.setAttribute("deptType",deptType);
        response.sendRedirect(request.getContextPath()+"/pages/organizer/addDept.jsp");
//        request.getRequestDispatcher("/pages/organizer/addDept.jsp").forward(request,response);
    }

    //添加Dept
    protected void addDept(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        Integer deptNo = Integer.valueOf(request.getParameter("deptNo"));
        final String deptName = request.getParameter("deptName");
        final String deptType = request.getParameter("deptType");
        deptService.add(deptNo,deptName,deptType);
        response.sendRedirect(request.getContextPath()+"/DeptServlet？methodName=selectDept&pageNo=1");
    }
    //修改
    protected void updateDept(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        System.out.println("修改");
        Integer deptNo = Integer.valueOf(request.getParameter("deptNo"));
        final String deptName = request.getParameter("deptName");
        final String deptType = request.getParameter("deptType");
        deptService.update(deptNo,deptName,deptType);
        HttpSession session = request.getSession();
        session.removeAttribute("deptNo");
        session.removeAttribute("deptName");
        session.removeAttribute("deptType");
//        response.sendRedirect(request.getContextPath()+"/pages/organizer/Dept.jsp");
        response.sendRedirect(request.getContextPath()+"/DeptServlet？methodName=selectDept&pageNo=1");

    }
    //删除
    protected void deletDept(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        Integer deptNo = Integer.valueOf(request.getParameter("deptNo"));
        deptService.delete(deptNo);
        response.sendRedirect(request.getContextPath()+"/DeptServlet?methodName=selectDept&pageNo=1");
//        请求服务器的地址 看后台的服务器
    }
    //查询，支持分页查询
    protected void selectDept(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("selectDept");
        request.setCharacterEncoding("UTF-8");
        String pageNo = request.getParameter("pageNo");
        final String deptType = request.getParameter("deptType");//机构 --
        int defaultPage=1;
        if (request.getParameter("pageNo") != null)
        {
            defaultPage = Integer.parseInt(request.getParameter("pageNo"));
        }
        Page<Dept> page=deptService.selectDept(defaultPage,deptType);
        request.setAttribute("deptList",page.getList());
        request.setAttribute("count",page.getTotalRecord());
        try {
            request.getRequestDispatcher("/pages/organizer/Dept.jsp").forward(request,response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
