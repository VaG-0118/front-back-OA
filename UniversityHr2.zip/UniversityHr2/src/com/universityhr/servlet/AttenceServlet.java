package com.universityhr.servlet;

import com.universityhr.bean.Applicant;
import com.universityhr.bean.Attence;
import com.universityhr.bean.Employee;
import com.universityhr.bean.Page;
import com.universityhr.service.AttenceService;
import com.universityhr.service.DeptService;
import com.universityhr.service.EmployeeService;
import com.universityhr.service.impl.AttenceServiceImpl;
import com.universityhr.service.impl.DeptServiceImpl;
import com.universityhr.service.impl.EmployeeServiceImpl;

import javax.accessibility.AccessibleText;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/AttenceServlet")
public class AttenceServlet extends BaseServlet {
    AttenceService attenceService=new AttenceServiceImpl();
    EmployeeService employeeService=new EmployeeServiceImpl();
    DeptService deptService=new DeptServiceImpl();

    /**
     * 添加考勤信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void attenceupload(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Attence attence=new Attence();
        attence.setEmpName(request.getParameter("name"));
        attence.setEmpID(Integer.parseInt(request.getParameter("empno")));

        attence.setEmpID(attence.getEmpID());
        attence.setDeptName(request.getParameter("dept"));
        if(request.getParameter("status").equals("option2")) {
            attence.setEmpStatus(0);
        } else {
            attence.setEmpStatus(1);
        }
        if (request.getParameter("attence").equals("option1")) {
            attence.setAttenceInfo("迟到早退");
        } else if(request.getParameter("attence").equals("option2")) {
            attence.setAttenceInfo("旷工");
        } else if(request.getParameter("attence").equals("option3")) {
            attence.setAttenceInfo("请假");
        } else if(request.getParameter("attence").equals("option4")) {
            attence.setAttenceInfo("加班");
        } else {
            attence.setAttenceInfo("正常");
        }
        attence.setDate(request.getParameter("date"));
        if (attenceService.add(attence)!=0) {
            System.out.println("插入成功");
            request.getRequestDispatcher("AttenceServlet?methodName=attenceinfo").forward(request,response);
        }

    }

    /**
     * 查看考勤信息页面
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void attenceinfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pageNo = request.getParameter("pageNo");
        int defaultPage=1;
        try {
            defaultPage= Integer.parseInt(pageNo);
        } catch (Exception e){
            System.out.println("错误");
            e.printStackTrace();
        }
        Page<Attence> page=attenceService.selectAllAttenceByPage(defaultPage);
        request.setAttribute("attences",page.getList());
        request.setAttribute("count",page.getTotalRecord());

        request.getRequestDispatcher("/pages/attence/attence.jsp").forward(request,response);
    }
    //按照人名搜搜
    protected void attenceinfobyselected(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pageNo = request.getParameter("pageNo");
        int defaultPage=1;
        try {
            defaultPage= Integer.parseInt(pageNo);
        } catch (Exception e){
            System.out.println("错误");
            e.printStackTrace();
        }
        int empno= employeeService.selectonebyname(request.getParameter("attencename")).getEmpID();
        Page<Attence> page=attenceService.selectoneEmpByEmpIDByPage(defaultPage,empno);
        request.setAttribute("attences",page.getList());
        request.setAttribute("count",attenceService.selectCountByEmpID(empno));
        request.getRequestDispatcher("/pages/attence/attence.jsp").forward(request,response);

    }
    //编辑功能
    protected void attenceedit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Attence attence=new Attence();
        attence.setEmpName(request.getParameter("aname"));
        Employee employee=employeeService.selectonebyname(attence.getEmpName());
        attence.setEmpID(employee.getEmpID());
        attence.setAttenceInfo(request.getParameter("attenceinfo"));
        attence.setDate(request.getParameter("date"));
        if (request.getParameter("gender").equals("男")) {
            attence.setGender(1);
        } else {
            attence.setGender(0);
        }
        int aid = Integer.parseInt(request.getParameter("aid"));
        attence.setId(aid);
        String deptname = deptService.selectNameById(employee.getDeptNO());
        attence.setDeptName(deptname);
        attenceService.update(attence);
        request.getRequestDispatcher("AttenceServlet?methodName=attenceinfo").forward(request,response);


    }
    //删除功能
    protected void attencedelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int aid = Integer.parseInt(request.getParameter("aid"));
        attenceService.deleteByid(aid);
        request.getRequestDispatcher("AttenceServlet?methodName=attenceinfo").forward(request,response);
    }


}
