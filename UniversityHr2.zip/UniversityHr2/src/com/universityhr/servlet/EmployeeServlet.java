package com.universityhr.servlet;

import com.universityhr.bean.Applicant;
import com.universityhr.bean.Employee;
import com.universityhr.bean.Page;
import com.universityhr.bean.Salary;
import com.universityhr.service.EmployeeService;
import com.universityhr.service.SalaryService;
import com.universityhr.service.impl.EmployeeServiceImpl;
import com.universityhr.service.impl.SalaryServiceImpl;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends BaseServlet {
    //设置编码，很重要，否则页面提交，中文会出现乱码

    private static final long serialVersionUID = 1L;


    /**
     * 实现查询分页的员工信息，点第几页，
     *增删改查，查先写分页查询，还有直接引用，共有多少数据
     *
     */

    //分页的方法
    protected void getPageEmployee(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pageNo = request.getParameter("pageNo");
        int defaultPage=1;
        try {
            defaultPage= Integer.parseInt(pageNo);
        } catch (Exception e){
            System.out.println("错误");
        }
        EmployeeService employeeService=new EmployeeServiceImpl();
       Page<Employee> page=employeeService.selectEmployee(defaultPage);

        request.setAttribute("employee",page.getList());
        request.setAttribute("count",page.getTotalRecord());
        try {
            request.getRequestDispatcher("/pages/employee/employee.jsp").forward(request,response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    //添加或更新员工
    protected void addOrUpdateEmployee(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取员工信息
        Integer empID = Integer.parseInt(request.getParameter("empID"));
        String empName=request.getParameter("empName");
        Integer gender=Integer.parseInt(request.getParameter("gender"));
        String birthday=request.getParameter("birthday");
        Integer politicalStatus=Integer.parseInt(request.getParameter("politicalStatus"));
        Integer deptNO=Integer.parseInt(request.getParameter("deptNO"));
        String professionalTitle=request.getParameter("professionalTitle");
        Integer empStatus=Integer.parseInt(request.getParameter("empStatus"));
        String empAddress=request.getParameter("empAddress");
        String emailAddr=request.getParameter("emailAddr");
        String telephone=request.getParameter("telephone");
        String QQ=request.getParameter("QQ");
        String education=request.getParameter("education");
        String university=request.getParameter("university");
        String intro=request.getParameter("intro");
        //根据id判断是在添加员工还是在更新员工
        if ("".equals(empID)) {
            //证明在添加员工
            //封装Employeee对象

            //调用EmployeeService中添加员工的方法
            EmployeeService employeeService= new EmployeeServiceImpl();

           employeeService.add(empID,  empName,  gender,  birthday,  politicalStatus,  deptNO,  professionalTitle,  empStatus);
        } else {
            //证明在更新员工

            //调用EmployeeService中更新员工的方法
            EmployeeService employeeService= new EmployeeServiceImpl();

           employeeService.update(empID,  empName,  gender,  birthday,  politicalStatus,  deptNO,  professionalTitle,  empStatus);
        }
        //重定向到查询所有员工的方法
        response.sendRedirect(request.getContextPath() + "/EmployeeServlet?methodName=updateEmployee");
    }

    //删除员工
    protected void deleteEmployee(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取要删除的员工的id
        int empID = Integer.parseInt(request.getParameter("empID"));
        //调用employeeService中删除员工的方法
        EmployeeService employeeService= new EmployeeServiceImpl();

      employeeService.delete(empID);
        //重定向到查询所有员工的方法
        response.sendRedirect(request.getContextPath() + "/EmployeeServlet?methodName=deleteEmployee");
    }

    //通过id获取employee的方法
    protected void getEmployeeById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取员工的id
        int empID = Integer.parseInt(request.getParameter("empID"));
        //调用EmployeeService中获取的方法
        EmployeeService employeeService= new EmployeeServiceImpl();
        Employee employeebyid = employeeService.selectonebyid(empID);

        //将员工信息放到request域中
       request.setAttribute("employee", employeebyid);
        //转发到修改员工的页面
        request.getRequestDispatcher("web/pages/employee/editemployee.jsp").forward(request, response);
    }

    //查询共有几条记录
    protected void select(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }



}
