package com.universityhr.servlet;

import com.sun.corba.se.spi.presentation.rmi.IDLNameTranslator;
import com.universityhr.bean.Attence;
import com.universityhr.bean.Employee;
import com.universityhr.bean.Page;
import com.universityhr.bean.Salary;
import com.universityhr.service.*;
import com.universityhr.service.impl.AttenceServiceImpl;
import com.universityhr.service.impl.DeptServiceImpl;
import com.universityhr.service.impl.EmployeeServiceImpl;
import com.universityhr.service.impl.SalaryServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/StaffServlet")
public class StaffServlet extends BaseServlet {

    EmployeeService employeeService=new EmployeeServiceImpl();
    DeptService deptService=new DeptServiceImpl();
    SalaryService salaryService=new SalaryServiceImpl();
    AttenceService attenceService=new AttenceServiceImpl();

    /**
     * 获取某一个普通职工的个人信息
     */
    protected void StaffInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // 获取session
        HttpSession session = request.getSession();
        // 获取session传过来的值
        String loginStaffName=(String)session.getAttribute("loginStaffName");
        final PrintWriter writer = response.getWriter();
        writer.write(loginStaffName);
        Employee employee = employeeService.selectonebyname(loginStaffName);
        //若找的到员工
        if(employee!=null)  {
            //员工的工号需要在emps中搜索到
            request.setAttribute("employee_empno",employee.getEmpID());
            request.setAttribute("employee_email",employee.getEmailAddr());
            request.setAttribute("employee_phone",employee.getTelephone());
            request.setAttribute("employee_qq",employee.getQQ());
            request.setAttribute("employee_address",employee.getEmpAddress());
            if(employee.getPoliticalStatus()==0) {
                request.setAttribute("employee_political_status", "群众");
            } else if(employee.getPoliticalStatus()==1) {
                request.setAttribute("employee_political_status", "共青团员");
            } else if(employee.getPoliticalStatus()==2) {
                request.setAttribute("employee_political_status", "中共党员");
            } else {
                request.setAttribute("employee_political_status", "民主党派");
            }
            request.setAttribute("employee_dept", deptService.selectNameById(employee.getDeptNO()));
            request.setAttribute("employee_position",employee.getProfessionalTitle());
            if (employee.getEmpStatus()==1) {
                request.setAttribute("employee_empstatus","在职");
            } else {
                request.setAttribute("employee_empstatus","离职");
            }
            request.setAttribute("employee_edu_background",employee.getEducation());
            request.setAttribute("employee_university",employee.getUniversity());
            request.setAttribute("employee_info",employee.getIntro());
        } else {
            employee=null;
        }
        request.setAttribute("employee",employee);
        request.getRequestDispatcher("/pages/user/userIndex.jsp").forward(request,response);

    }
    /**
     * 上传某一个普通职工的个人信息
     * 实现将职工的个人信息储存到emps数据库中 同时实现将position储存到salary的job中
     * 使用了add（employee）方法
     */
    protected void StaffUpload(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

        // 获取session
        HttpSession session = request.getSession();
        // 获取session传过来的值
        String loginStaffName=(String)session.getAttribute("loginStaffName");
        Employee employee=new Employee();
        employee.setEmpName(loginStaffName);//设置姓名

        //设置部门
        employee.setDeptNO(deptService.selectIdByName(request.getParameter("deptname")));

        //从jsp页面上获取用户输入的数据
        if(request.getParameter("user-gender").equals("男")) {
            employee.setGender(1);//若页面为男，employee性别为1
        } else {
            employee.setGender(0);//女为0
        }//设置性别
        employee.setBirthday(request.getParameter("user-birthday"));//设置生日

        final String edu_background = request.getParameter("edu_background");
        if (edu_background.equals("option1")) {
            employee.setEducation("本科");
        } else if(edu_background.equals("option2")) {
            employee.setEducation("学士");
        } else if(edu_background.equals("option3")) {
            employee.setEducation("硕士研究生");
        } else if(edu_background.equals("option4")) {
            employee.setEducation("博士研究生");
        } else if(edu_background.equals("option5")) {
            employee.setEducation("博士后");
        } else if(edu_background.equals("option6")) {
            employee.setEducation("中专");
        } else if(edu_background.equals("option7")) {
            employee.setEducation("大专");
        } else if(edu_background.equals("option8")) {
            employee.setEducation("高中");
        }
        //设置政治面貌
        if (request.getParameter("political_status").equals("option1")) {
            employee.setPoliticalStatus(0);
        }
        else if(request.getParameter("political_status").equals("option2")) {
            employee.setPoliticalStatus(1);
        }
        else if(request.getParameter("political_status").equals("option3")) {
            employee.setPoliticalStatus(2);
        }
        else {
            employee.setPoliticalStatus(3);
        }
        //职称从页面中获取
        //单选按钮的获取值
        if (request.getParameter("professional_title").equals("option1")) {
            employee.setProfessionalTitle("正高级");
        } else if (request.getParameter("professional_title").equals("option2")){
            employee.setProfessionalTitle("副高级");
        } else if (request.getParameter("professional_title").equals("option3")) {
            employee.setProfessionalTitle("中级");
        } else if (request.getParameter("professional_title").equals("option4")){
            employee.setProfessionalTitle("初级");
        }


        employee.setEmpStatus(1);//状态默认为在职
        employee.setEmpAddress(request.getParameter("user-address"));
        employee.setEmailAddr(request.getParameter("user-email"));
        employee.setTelephone(request.getParameter("user-phone"));
        employee.setQQ(request.getParameter("user-QQ"));
        employee.setUniversity(request.getParameter("user-school"));
        employee.setIntro(request.getParameter("info"));
        if(employeeService.addEmployee(employee)!=0) {
            try {
                request.getRequestDispatcher("StaffServlet?methodName=StaffInfo").forward(request,response);

            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("添加数据失败");
        }

    }

    /**
     * 修改个人信息
     * @param request
     * @param response
     */
    protected void StaffEdit1(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {

        // 获取session
        HttpSession session = request.getSession();
        // 获取session传过来的值
        String loginStaffName=(String)session.getAttribute("loginStaffName");


        //从数据库获取以前的旧数据
        Employee employee1 = employeeService.selectonebyname(loginStaffName);
        //若找的到员工
        if(employee1!=null)  {
            //员工的工号需要在emps中搜索到
            request.setAttribute("employee_gender",employee1.getGender());
            request.setAttribute("employee_email",employee1.getEmailAddr());
            request.setAttribute("employee_phone",employee1.getTelephone());
            request.setAttribute("employee_qq",employee1.getQQ());
            request.setAttribute("employee_birthday",employee1.getBirthday());
            request.setAttribute("employee_address",employee1.getEmpAddress());
            request.setAttribute("employee_dept", deptService.selectNameById(employee1.getDeptNO()));
            request.setAttribute("employee_university",employee1.getUniversity());
            request.setAttribute("employee_info",employee1.getIntro());
        } else {
            employee1=null;
        }
        request.getRequestDispatcher("/pages/user/userEdit.jsp").forward(request,response);



    }
    protected void StaffEdit2(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        // 获取session
        HttpSession session = request.getSession();
        // 获取session传过来的值
        String loginStaffName=(String)session.getAttribute("loginStaffName");
        Employee employee=new Employee();
        employee.setEmpName(loginStaffName);//设置姓名
        //设置empid
        employee.setGender(1);
        employee.setEmpID(employeeService.selectonebyname(loginStaffName).getEmpID());
        //从jsp页面上获取用户输入的数据
        employee.setBirthday(request.getParameter("user-birthday"));//设置生日
        //设置部门
        Integer deptid = deptService.selectIdByName(request.getParameter("dept"));
        employee.setDeptNO(deptid);
        //设置政治面貌
        if (request.getParameter("political_status").equals("option1")) {
            employee.setPoliticalStatus(0);
        }
        else if(request.getParameter("political_status").equals("option2")) {
            employee.setPoliticalStatus(1);
        }
        else if(request.getParameter("political_status").equals("option3")) {
            employee.setPoliticalStatus(2);
        }
        else {
            employee.setPoliticalStatus(3);
        }
        //职称从页面中获取
        //单选按钮的获取值
        if (request.getParameter("professional_title").equals("option1")) {
            employee.setProfessionalTitle("正高级");
        } else if (request.getParameter("professional_title").equals("option2")){
            employee.setProfessionalTitle("副高级");
        } else if (request.getParameter("professional_title").equals("option3")) {
            employee.setProfessionalTitle("中级");
        } else if (request.getParameter("professional_title").equals("option4")){
            employee.setProfessionalTitle("初级");
        }

        employee.setEmpStatus(1);//状态默认为在职
        employee.setEmpAddress(request.getParameter("user-address"));
        employee.setEmailAddr(request.getParameter("user-email"));
        employee.setTelephone(request.getParameter("user-phone"));
        if(employeeService.updateEmployee(employee)!=0) {
            try {
                request.getRequestDispatcher("StaffServlet?methodName=StaffInfo").forward(request,response);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("添加数据失败");
        }

    }
    //获取个人的详细薪资和考勤记录
    protected void StaffSalarys(HttpServletRequest request, HttpServletResponse response) {
        // 获取session
        HttpSession session = request.getSession();
        // 获取session传过来的值
        String loginStaffName=(String)session.getAttribute("loginStaffName");
        Employee employee=new Employee();
        employee.setEmpName(loginStaffName);//设置姓名
        //从数据库中获得员工的id号
        employee.setEmpID(employeeService.selectonebyname(loginStaffName).getEmpID());
        //获得pageno
        String pageNo = request.getParameter("pageNo");
        Integer passStatus;
        int defaultPage=1;
        try {
            defaultPage= Integer.parseInt(pageNo);
        } catch (Exception e){
            System.out.println("错误");
        }
        //从数据库中获取薪资信息
        Page<Salary> page = salaryService.selectEmpIDByPage(defaultPage, employeeService.selectonebyname(loginStaffName).getEmpID());
        request.setAttribute("salarys",page.getList());
        request.setAttribute("salarycount",salaryService.selectCountByEmpID(employeeService.selectonebyname(loginStaffName).getEmpID()));
        //从数据库中获取薪资信息
        Page<Attence> page2=attenceService.selectoneEmpByEmpIDByPage(defaultPage,employeeService.selectonebyname(loginStaffName).getEmpID());
        request.setAttribute("attences",page2.getList());
        request.setAttribute("attencecount",attenceService.selectCountByEmpID(employeeService.selectonebyname(loginStaffName).getEmpID()));
        //转发
        try {
            request.getRequestDispatcher("/pages/user/userInfo.jsp").forward(request,response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    //通过下拉框选择薪资信息
    protected void StaffSalarysbyselected(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取session
        HttpSession session = request.getSession();
        // 获取session传过来的值
        String loginStaffName=(String)session.getAttribute("loginStaffName");
        Employee employee=new Employee();
        employee.setEmpName(loginStaffName);//设置姓名
        //从数据库中获得员工的id号
        employee.setEmpID(employeeService.selectonebyname(loginStaffName).getEmpID());
        //获得pageno
        String pageNo = request.getParameter("pageNo");
        Integer passStatus;
        int defaultPage=1;
        try {
            defaultPage= Integer.parseInt(pageNo);
        } catch (Exception e){
            System.out.println("错误");
        }
        String option=request.getParameter("recordselected");
        //从数据库中获取薪资信息
        if (request.getParameter("recordselected").equals("option2")) {
            //本月查询薪资信息
            Page<Salary> page = salaryService.selectthismonth(defaultPage, employeeService.selectonebyname(loginStaffName).getEmpID());
            request.setAttribute("salarys",page.getList());
            request.setAttribute("salarycount",salaryService.selectCountByEmpIDThisMonth(employeeService.selectonebyname(loginStaffName).getEmpID()));
            //查询全部的考勤信息
            Page<Attence> page2=attenceService.selectoneEmpByEmpIDByPage(defaultPage,employeeService.selectonebyname(loginStaffName).getEmpID());
            request.setAttribute("attences",page2.getList());
            request.setAttribute("attencecount",attenceService.selectCountByEmpID(employeeService.selectonebyname(loginStaffName).getEmpID()));
            request.getRequestDispatcher("/pages/user/userInfo.jsp").forward(request,response);
        } else if(request.getParameter("recordselected").equals("option3")) {
            //本年查询薪资信息
            Page<Salary> page = salaryService.selectthisyear(defaultPage, employeeService.selectonebyname(loginStaffName).getEmpID());
            request.setAttribute("salarys",page.getList());
            request.setAttribute("salarycount",salaryService.selectCountByEmpIDThisYear(employeeService.selectonebyname(loginStaffName).getEmpID()));
            //查询全部的考勤信息
            Page<Attence> page2=attenceService.selectoneEmpByEmpIDByPage(defaultPage,employeeService.selectonebyname(loginStaffName).getEmpID());
            request.setAttribute("attences",page2.getList());
            request.setAttribute("attencecount",attenceService.selectCountByEmpID(employeeService.selectonebyname(loginStaffName).getEmpID()));
            request.getRequestDispatcher("/pages/user/userInfo.jsp").forward(request,response);
        } else {
                request.getRequestDispatcher("/StaffServlet?methodName=StaffSalarys").forward(request,response);
        }


    }

}

