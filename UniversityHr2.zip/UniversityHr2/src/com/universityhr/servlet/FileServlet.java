package com.universityhr.servlet;

import com.universityhr.bean.File;
import com.universityhr.bean.Page;
import com.universityhr.service.impl.FileServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/FileServlet")
public class FileServlet extends BaseServlet
{
    FileServiceImpl fileService = new FileServiceImpl();

    protected void addFile(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        PrintWriter out = response.getWriter();
        File file = new File();

        file.setFileName(request.getParameter("fileName"));
        file.setFileType(request.getParameter("fileType"));
        file.setAuthor(request.getParameter("fileAuthor"));
        file.setDate(request.getParameter("date"));

        fileService.add(file);
        request.getRequestDispatcher("FileServlet?methodName=selectAllFile").forward(request, response);
    }

    protected void editFile(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        File file = new File();
        file.setId(Integer.valueOf(request.getParameter("fileID")).intValue());
        file.setFileName(request.getParameter("fileName"));
        file.setFileType(request.getParameter("fileType"));
        file.setAuthor(request.getParameter("fileAuthor"));
        file.setDate(request.getParameter("date"));

        fileService.update(file);
        request.getRequestDispatcher("FileServlet?methodName=selectAllFile").forward(request, response);
    }

    protected void deleteFile(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        int id = Integer.valueOf(request.getParameter("fileID")).intValue();

        fileService.deleteByid(id);
        request.getRequestDispatcher("FileServlet?methodName=selectAllFile").forward(request, response);
    }

    protected void selectAllFile(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        int defaultPageNo = 1;
        if (request.getParameter("pageNo") != null)
        {
            defaultPageNo = Integer.parseInt(request.getParameter("pageNo"));
        }

        Page<File> page = fileService.selecFilePage(1);
        request.setAttribute("Files", page.getList());
        request.setAttribute("entityAmount", page.getTotalRecord());
        request.setAttribute("pageAmount", page.getTotalPageNo());
        request.getRequestDispatcher("/pages/file/FileManagement.jsp").forward(request, response);

    }

    protected void searchFile(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        int defaultPageNo = 1;
        if (request.getParameter("pageNo") != null)
        {
            defaultPageNo = Integer.parseInt(request.getParameter("pageNo"));
        }
        String fileName = request.getParameter("fileName");
        Page<File> page = new Page<File>();
        try
        {
            page = fileService.selectFileByName(page, fileName);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        if (page == null)
        {
            request.setAttribute("serverMsg", "    无对应搜索记录");
            request.getRequestDispatcher("/pages/file/FileManagement.jsp").forward(request, response);
            return;
        }
        request.setAttribute("Files", page.getList());
        request.setAttribute("entityAmount", page.getTotalRecord());
        request.setAttribute("pageAmount", page.getTotalPageNo());

        request.getRequestDispatcher("/pages/file/FileManagement.jsp").forward(request, response);
    }
}
