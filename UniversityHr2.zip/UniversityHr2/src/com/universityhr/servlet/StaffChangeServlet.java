package com.universityhr.servlet;

import com.universityhr.bean.Page;
import com.universityhr.bean.StaffChangeLog;
import com.universityhr.service.impl.StaffChangeLogServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/StaffLogServlet")
public class StaffChangeServlet extends BaseServlet
{
    StaffChangeLogServiceImpl staffChangeLogService = new StaffChangeLogServiceImpl();

    protected void selectAllRecord(HttpServletRequest request, HttpServletResponse response)
    {
        int defaultPageNo = 1;
        if (request.getParameter("pageNo") != null)
        {
            defaultPageNo = Integer.parseInt(request.getParameter("pageNo"));
        }
        try
        {
            Page<StaffChangeLog> page =  staffChangeLogService.selectAllLog(1);
            if(page == null)
            {
                request.setAttribute("serverMsg", "    无对应搜索记录");
                request.getRequestDispatcher("/pages/staff/StaffLog.jsp").forward(request, response);
                return;
            }
            request.setAttribute("records", page.getList());
            request.setAttribute("entityAmount", page.getTotalRecord());
            request.setAttribute("pageAmount", page.getTotalPageNo());

            request.getRequestDispatcher("/pages/staff/StaffLog.jsp").forward(request, response);
        }
        catch (ServletException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    protected void addLog(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        StaffChangeLog staffChangeLog = new StaffChangeLog();
        staffChangeLog.setName(request.getParameter("stuffName"));
        staffChangeLog.setPost(request.getParameter("stuffDuty"));
        staffChangeLog.setType(request.getParameter("recordType"));
        staffChangeLog.setDate(request.getParameter("recordDate"));
        staffChangeLogService.add(staffChangeLog);
        request.getRequestDispatcher("StaffLogServlet?methodName=selectAllRecord").forward(request, response);
    }
}
