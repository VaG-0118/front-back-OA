package com.universityhr.servlet;
import javax.servlet.http.HttpSession;
import com.universityhr.bean.ManagerUser;
import com.universityhr.bean.StaffUser;
import com.universityhr.service.ManagerUserService;
import com.universityhr.service.StaffUserService;
import com.universityhr.service.impl.ManagerUserServiceImpl;
import com.universityhr.service.impl.StaffUserServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@WebServlet("/UserServlet")
public class UserServlet extends BaseServlet{
    private ManagerUserService managerUserService =new ManagerUserServiceImpl();
    private StaffUserService staffUserService =new StaffUserServiceImpl();


    /**
     * 管理人员的登录
     */
    protected void LoginManager(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        final String username = request.getParameter("username");
        final String password = request.getParameter("password");

        if (managerUserService.login(username,password)==null) {
            final RequestDispatcher requestDispatcher = request.getRequestDispatcher("/pages/user/loginManager.jsp");

            request.setAttribute("msg","用户名或密码不正确");
            request.setAttribute("username",username);

            requestDispatcher.forward(request,response);

        } else {
            //获取该页面的对象
            final HttpSession session = request.getSession();
            //把登录的名字放入session中，注意session不能让太多东西
            session.setAttribute("loginManagerName",username);

            request.getRequestDispatcher("ApplicantServlet?methodName=applicantinfo").forward(request,response);

        }
    }
    /**
     * 普通职工的登录
     */
    protected void LoginStaff(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        final String username = request.getParameter("username");
        final String password = request.getParameter("password");

        if (managerUserService.login(username,password)==null) {
            final RequestDispatcher requestDispatcher = request.getRequestDispatcher("/pages/user/loginManager.jsp");

            request.setAttribute("msg","用户名或密码不正确");
            request.setAttribute("username",username);

            requestDispatcher.forward(request,response);

        } else {
            final HttpSession session = request.getSession();
            //将登录上去的普通教职工的名字放入session中
            session.setAttribute("loginStaffName",username);
            request.getRequestDispatcher("/StaffServlet?methodName=StaffInfo").forward(request,response);
        }
    }
    /**
     * 普通职工注册
     */
    protected void RegisterStaff(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        //获取网页请求参数name=""中的字段
        final String username = request.getParameter("username");
        final String password1 = request.getParameter("password1");
        final String password2 = request.getParameter("password2");
        final String email=request.getParameter("email");
        if (!password1.equals(password2)) {
            final RequestDispatcher requestDispatcher = request.getRequestDispatcher("/pages/user/registerStaff.jsp");
            request.setAttribute("msg","两次输入的密码不一致");
            request.setAttribute("username",username);
            requestDispatcher.forward(request,response);
        } else{
            StaffUser user=new StaffUser(username,password1,email);

            //调用service方法
            if(staffUserService.register(user)==true) {
                request.getRequestDispatcher("/StaffServlet?methodName=StaffInfo").forward(request,response);
            } else {
                final RequestDispatcher requestDispatcher = request.getRequestDispatcher("/pages/user/registerStaff.jsp");
                request.setAttribute("msg","因为数据库写入数据出错导致无法注册成功");
                requestDispatcher.forward(request,response);
            }
        }
    }
    /**
     * 管理人员的注册
     */
    protected void RegisterManager(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        final String username = request.getParameter("username");
        final String password1 = request.getParameter("password1");
        final String password2 = request.getParameter("password2");
        final String email=request.getParameter("email");
        if (!password1.equals(password2)) {
            final RequestDispatcher requestDispatcher = request.getRequestDispatcher("/pages/user/registerStaff.jsp");
            request.setAttribute("msg","两次输入的密码不一致");
            request.setAttribute("username",username);
            requestDispatcher.forward(request,response);
        } else{
            ManagerUser user=new ManagerUser(username,password1,email);

            //调用service方法
            if(managerUserService.register(user)==true) {
                request.getRequestDispatcher("ApplicantServlet?methodName=applicantinfo").forward(request,response);
            } else {
                final RequestDispatcher requestDispatcher = request.getRequestDispatcher("/pages/user/registerStaff.jsp");
                request.setAttribute("msg","因为数据库写入数据出错导致无法注册成功");
                requestDispatcher.forward(request,response);
            }
        }
    }

    /**
     * 管理人员的注销功能
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void LogoutManager(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //强制让session失效
        request.getSession().invalidate();
        response.sendRedirect(request.getContextPath()+"/pages/user/loginManager.jsp");
    }
    /**
     * 管理人员的注销功能
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void LogoutStaff(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //强制让session失效
        request.getSession().invalidate();
        response.sendRedirect(request.getContextPath()+"/pages/user/loginStaff.jsp");
    }

    

}
