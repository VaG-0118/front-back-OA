package com.universityhr.servlet;

import com.universityhr.bean.Applicant;
import com.universityhr.bean.Page;
import com.universityhr.service.ApplicantService;
import com.universityhr.service.impl.ApplicantServiceImpl;
import org.omg.CORBA.INTERNAL;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/ApplicantServlet")
public class ApplicantServlet extends BaseServlet {
    ApplicantService applicantService=new ApplicantServiceImpl();

    /**
     * 实现applicant的信息分页展示，展示所有信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void applicantinfo(HttpServletRequest request, HttpServletResponse response) {
        String pageNo = request.getParameter("pageNo");
        int defaultPage=1;
        try {
            defaultPage= Integer.parseInt(pageNo);
        } catch (Exception e){
            System.out.println("错误");
        }
        Page<Applicant> page=applicantService.selectAllApplicant(defaultPage);
        request.setAttribute("applicants",page.getList());
        request.setAttribute("count",page.getTotalRecord());
        try {
            request.getRequestDispatcher("/pages/applicant/applicant.jsp").forward(request,response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void applicantdetails(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Applicant> applicants = applicantService.selectAllApplicantByName(1,request.getParameter("Name")).getList();
        Applicant applicant=applicants.get(0);
        request.setAttribute("applicant",applicant);
        request.getRequestDispatcher("/pages/applicant/applicantdetails.jsp").forward(request,response);
    }

    //按照状态查找 已通过，已拒绝，待审核
    protected void applicantselectbytype(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pageNo = request.getParameter("pageNo");
        Integer passStatus;
        int defaultPage=1;
        try {
            defaultPage= Integer.parseInt(pageNo);
        } catch (Exception e){
            System.out.println("错误");
        }
        if (request.getParameter("type").equals("已通过")) {
            passStatus=1;
        } else if (request.getParameter("type").equals("已拒绝")) {
            passStatus=0;
        } else {
            passStatus=2;
        }
        List<Applicant> applicants = applicantService.selectAllApplicantByPassStatus(defaultPage,passStatus).getList();
        request.setAttribute("applicants",applicants);
        request.setAttribute("count",applicants.size());
        request.getRequestDispatcher("/pages/applicant/applicant.jsp").forward(request,response);
    }

    //改变应聘人员审核状态
    protected void changestatus(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //数据库更改状态
        String applicantName = request.getParameter("applicantName");
        Applicant applicant=applicantService.selectAllApplicantByName(1,applicantName).getList().get(0);
        applicantService.changeStatusById(applicant.getId(),0);
        //首页显示所有对象的信息

        String pageNo = request.getParameter("pageNo");
        int defaultPage=1;
        try {
            defaultPage= Integer.parseInt(pageNo);
        } catch (Exception e){
            System.out.println("错误");
        }
        Page<Applicant> page=applicantService.selectAllApplicant(defaultPage);
        request.setAttribute("applicants",page.getList());
        request.setAttribute("count",page.getTotalRecord());

        request.getRequestDispatcher("/pages/applicant/applicant.jsp").forward(request,response);

    }
    //add页面上的状态修改为已拒绝功能
    protected void refuseapplicant(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //数据库更改状态
        String applicantName = request.getParameter("applicantName");
        Applicant applicant=applicantService.selectAllApplicantByName(1,applicantName).getList().get(0);
        applicantService.changeStatusById(applicant.getId(),0);
        //首页显示所有对象的信息

        String pageNo = request.getParameter("pageNo");
        int defaultPage=1;
        try {
            defaultPage= Integer.parseInt(pageNo);
        } catch (Exception e){
            System.out.println("错误");
        }
        Page<Applicant> page=applicantService.selectAllApplicant(defaultPage);
        request.setAttribute("applicants",page.getList());
        request.setAttribute("count",page.getTotalRecord());

        request.getRequestDispatcher("/pages/applicant/applicant.jsp").forward(request,response);

    }
    //add页面上的状态修改为同意功能
    protected void agreeapplicant(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //数据库更改状态
        String applicantName = request.getParameter("applicantName");
        Applicant applicant=applicantService.selectAllApplicantByName(1,applicantName).getList().get(0);
        applicantService.changeStatusById(applicant.getId(),1);
        //首页显示所有对象的信息

        String pageNo = request.getParameter("pageNo");
        int defaultPage=1;
        try {
            defaultPage= Integer.parseInt(pageNo);
        } catch (Exception e){
            System.out.println("错误");
        }
        Page<Applicant> page=applicantService.selectAllApplicant(defaultPage);
        request.setAttribute("applicants",page.getList());
        request.setAttribute("count",page.getTotalRecord());

        request.getRequestDispatcher("/pages/applicant/applicant.jsp").forward(request,response);

    }

}
