package com.universityhr.dao;

import com.universityhr.bean.Applicant;
import com.universityhr.bean.Page;

public interface ApplicantDao extends BasicDao<Applicant>
{

    Page<Applicant> selectAllApplicant(Page<Applicant> page);

    Page<Applicant> selectAllApplicantByName(Page<Applicant> page, String name);

    Page<Applicant> selectAllApplicantByPassStatus(Page<Applicant> page, Integer passStatus);
    int changeStatusById(Integer id, Integer newStatus);
}
