package com.universityhr.dao;

import com.universityhr.bean.StaffUser;

public interface StaffUserDao<T>
{
    // 获取用户
    StaffUser getUser(String username);

    // 更新、保存用户信息
    int saveUser(T user);

    // 添加用户
    int addUser(T user);

}
