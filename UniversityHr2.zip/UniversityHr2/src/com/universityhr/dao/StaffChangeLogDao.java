package com.universityhr.dao;

import com.universityhr.bean.Page;
import com.universityhr.bean.StaffChangeLog;

public interface StaffChangeLogDao extends BasicDao<StaffChangeLog>
{
    Page<StaffChangeLog> selectAllLog(Page<StaffChangeLog> page);

    Page<StaffChangeLog> selectAllLogByEmpID(Page<StaffChangeLog> page, Integer empID);

    Page<StaffChangeLog> selectAllLogByType(Page<StaffChangeLog> page, String type);
}
