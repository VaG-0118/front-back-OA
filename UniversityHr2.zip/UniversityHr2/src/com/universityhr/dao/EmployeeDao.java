package com.universityhr.dao;

import com.universityhr.bean.Employee;
import com.universityhr.bean.Page;

public interface EmployeeDao<T> extends BasicDao<Employee>
{
    // 按员工名查询
    T selectByName(String empname);

    int setEmpStatus(String empname, Integer newStatus);

    Page<T> selectByPage(Page<Employee> page);

    long selectCount();
}
