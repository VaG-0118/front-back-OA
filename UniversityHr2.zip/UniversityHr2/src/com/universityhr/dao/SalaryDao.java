package com.universityhr.dao;

import com.universityhr.bean.Page;
import com.universityhr.bean.Salary;

public interface SalaryDao extends BasicDao<Salary>
{
    Page<Salary> selectEmpIDByPage(Page<Salary> page, int empID);

    Page<Salary> selectAllSalaryByPage(Page<Salary> page);

    Page<Salary> selectEmpIDByPageThisMonth(Page<Salary> page, int empID);

    Page<Salary> selectEmpIDByPageThisYear(Page<Salary> page, int empID);

    long selectCount();

    long selectCountByEmpID(int empID);

    long selectCountByEmpIDThisMonth(int empID);

    long selectCountByEmpIDThisYear(int empID);
}
