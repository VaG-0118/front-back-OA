package com.universityhr.dao.impl;

import com.universityhr.bean.Applicant;
import com.universityhr.bean.Page;
import com.universityhr.bean.StaffChangeLog;
import com.universityhr.dao.ApplicantDao;

import java.sql.SQLException;
import java.util.List;

public class ApplicantDaoImpl extends BasicDaoImpl<Applicant> implements ApplicantDao
{
    // 查询所有应聘记录
    @Override
    public Page<Applicant> selectAllApplicant(Page<Applicant> page)
    {
        String sql = "select count(*) from applicant";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select * from applicant order by submitDate desc limit ?, ?";
        try
        {
            page.setList(
                    getList(Applicant.class,
                            sql2,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    // 查询个人所有应聘记录
    @Override
    public Page<Applicant> selectAllApplicantByName(Page<Applicant> page, String name)
    {
        String sql = "select count(*) from applicant";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select * from applicant where personName=? order by submitDate desc limit ?, ?";
        try
        {
            page.setList(
                    getList(Applicant.class,
                            sql2,
                            name,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    // 按通过状态查询所有记录(1 == 通过, 0 == 等待审查, 2 == 拒绝)
    @Override
    public Page<Applicant> selectAllApplicantByPassStatus(Page<Applicant> page, Integer passStatus)
    {
        String sql = "select count(*) from applicant";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select * from applicant where passStatus=? order by submitDate desc limit ?, ?";
        try
        {
            page.setList(
                    getList(Applicant.class,
                            sql2,
                            passStatus,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    @Override
    public int insert(Applicant entity)
    {
        String sql = "insert into Applicant values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        int count = 0;
        try
        {
            count = update(sql,
                    null,
                    entity.getPersonName(),
                    entity.getGender(),
                    entity.getPurposePost(),
                    entity.getEducation(),
                    entity.getWorkExperience(),
                    entity.getPassStatus(),
                    entity.getEmailAddr(),
                    entity.getQQ(),
                    entity.getWorkExpDetail(),
                    entity.getOtherExpDetail(),
                    entity.getTelephone(),
                    entity.getSubmitDate(),
                    entity.getPurposeSalary());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }
    public int changeStatusById(Integer id, Integer newStatus)
    {
        String sql = "update applicant set passStatus = ? where id = ?";
        int count = 0;
        try
        {
            count = update(sql, newStatus, id);
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }
    // 空实现(应聘界面无需编辑)
    @Override
    public int update(Applicant entity)
    {
        return 0;
    }

    // 空实现(应聘界面无需删除)
    @Override
    public int deleteById(Integer id)
    {
        return 0;
    }

    // 空实现
    @Override
    public Applicant selectOneById(Integer id)
    {
        return null;
    }

    // 空实现
    @Override
    public List<Applicant> selectList()
    {
        return null;
    }


}
