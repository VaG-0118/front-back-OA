package com.universityhr.dao.impl;

import com.universityhr.bean.Applicant;
import com.universityhr.bean.File;
import com.universityhr.bean.Page;
import com.universityhr.dao.FileDao;

import java.sql.SQLException;
import java.util.List;

public class FileDaoImpl extends BasicDaoImpl<File> implements FileDao
{

    @Override
    public int insert(File entity)
    {
        String sql = "insert into file values(?,?,?,?,?)";
        int count = 0;
        try
        {
            count = update(sql,
                    null,
                    entity.getFileName(),
                    entity.getFileType(),
                    entity.getAuthor(),
                    entity.getDate());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }

        return count;
    }

    @Override
    public int update(File entity)
    {
        String sql = "update file set fileName=?, fileType=?, author=?, date=? where id=?";
        int count = 0;
        try
        {
            count = update(sql,
                    entity.getFileName(),
                    entity.getFileType(),
                    entity.getAuthor(),
                    entity.getDate(),
                    entity.getId());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    @Override
    public int deleteById(Integer id)
    {
        String sql = "delete from file where id=?";
        int count = 0;
        try
        {
            count = update(sql, id);
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    // 按文件ID查询
    @Override
    public File selectOneById(Integer id)
    {
        String sql = "select * from file where id=?";

        File file = null;
        try
        {
            file = getBean(File.class, sql, id);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return file;
    }

    // 空实现
    @Override
    public List<File> selectList()
    {
        return null;
    }

    @Override
    public Page<File> selectFileByPage(Page<File> page)
    {
        String sql = "select count(*) from file";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select * from file order by date desc limit ?,?";
        try
        {
            page.setList(getList(File.class, sql2, (page.getPageNo() - 1) * page.getPageSize(), page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    @Override
    public File selectFileName(String fileName)
    {
        fileName = "%" + fileName + "%";
        String sql = "select * from file where filename like ? order by date desc";
        File file = null;
        try
        {
            file = getBean(File.class, sql, fileName);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return file;
    }


    @Override
    public long selectCount()
    {
        String sql = "select count(*) from file";
        long count = (long) getSingleValue(sql);
        return count;
    }


    public Page<File> selectFileByName(Page<File> page, String name)
    {
        name = "%" + name + "%";
        String sql = "select count(*) from file where fileName like ?";
        long count = 0;
        count = (long) getSingleValue(sql, name);
        if(count == 0)
        {
            page = null;
            return page;
        }
        page.setTotalRecord((int) count);
        String sql2 = "select * from file where fileName like ? order by date desc limit ?, ?";
        int test = (page.getPageNo() - 1);
        test *= page.getPageSize();
        test = page.getPageSize();
        try
        {
            page.setList(
                    getList(File.class,
                            sql2,
                            name,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }
}
