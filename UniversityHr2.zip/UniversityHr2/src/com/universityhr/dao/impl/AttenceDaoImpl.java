package com.universityhr.dao.impl;

import com.universityhr.bean.Attence;
import com.universityhr.bean.Dept;
import com.universityhr.bean.Page;
import com.universityhr.dao.AttenceDao;

import java.sql.SQLException;
import java.util.List;

public class AttenceDaoImpl extends BasicDaoImpl<Attence> implements AttenceDao
{
    // 按empID、考勤类型查询次数
    @Override
    public long selectAttenceInfoByEmpID(Integer empID, String attenceInfo)
    {
        String sql = "select count(*) from Attence where empID=? and attenceInfo=?";
        long count = 0;
        try
        {
            count = (long) getSingleValue(sql, empID, attenceInfo);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    // 查询所有考勤信息
    @Override
    public Page<Attence> selectAllAttenceByPage(Page<Attence> page)
    {
        String sql = "select count(*) from Attence";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select attence.id, emps.empName, emps.gender, dept.deptName, emps.empStatus, attence.attenceInfo,attence.date from emps, attence, dept " +
                "where emps.deptNO = dept.deptNO and emps.empID = attence.empID order by date desc limit ?, ?";
        try
        {
            page.setList(
                    getList(Attence.class,
                            sql2,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    // 查询某员工所有考勤信息
    @Override
    public Page<Attence> selectAllAttenceByEmpIDByPage(Page<Attence> page, int empID)
    {
        String sql = "select count(*) from Attence";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select attence.id, emps.empName, emps.gender, dept.deptName, emps.empStatus, attence.attenceInfo,attence.date from emps, attence, dept " +
                "where emps.deptNO = dept.deptNO and emps.empID = attence.empID and attence.empID=? order by date desc limit ?, ?";
        try
        {
            page.setList(
                    getList(Attence.class,
                            sql2,
                            empID,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    // 查询本月某员工出勤
    @Override
    public Page<Attence> selectAttenceByEmpIDThisMonth(Page<Attence> page, int empID)
    {
        String sql = "select count(*) from Attence";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select id, empName, gender, deptName, empStatus, attenceInfo, date from " +
                "(select attence.id, emps.empName, emps.gender, dept.deptName, emps.empStatus, attence.attenceInfo,attence.date, datediff(now(),attence.date) datediffenent" +
                " from emps, attence, dept where emps.deptNO = dept.deptNO and emps.empID = attence.empID and attence.empID = ?) new_table " +
                "where datediffenent <= 30 order by date desc limit ?, ?";
        try
        {
            page.setList(
                    getList(Attence.class,
                            sql2,
                            empID,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    // 查询本年某员工出勤
    @Override
    public Page<Attence> selectAttenceByEmpIDThisYear(Page<Attence> page, int empID)
    {
        String sql = "select count(*) from Attence";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select id, empName, gender, deptName, empStatus, attenceInfo, date from " +
                "(select attence.id, emps.empName, emps.gender, dept.deptName, emps.empStatus, attence.attenceInfo,attence.date, datediff(now(),attence.date) datediffenent" +
                " from emps, attence, dept where emps.deptNO = dept.deptNO and emps.empID = attence.empID and attence.empID = ?) new_table " +
                "where datediffenent <= 360 order by date desc limit ?, ?";
        try
        {
            page.setList(
                    getList(Attence.class,
                            sql2,
                            empID,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    // 插入考勤信息
    @Override
    public int insert(Attence entity)
    {
        String sql = "insert into Attence (empID, attenceInfo, date) values(?,?,?)";
        int count = 0;
        try
        {
            count = update(sql, entity.getEmpID(), entity.getAttenceInfo(), entity.getDate());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    // 按ID更新
    @Override
    public int update(Attence entity)
    {
        String sql = "update attence set attenceInfo=?, date=? where id=?";
        int count = 0;
        try
        {
            count = update(sql, entity.getAttenceInfo(), entity.getDate(), entity.getId());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    // 空实现
    @Override
    public int deleteById(Integer id)
    {
        String sql = "delete from Attence where id = ?";
        int count = 0;
        try
        {
            count = update(sql, id);
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    // 空实现
    @Override
    public Attence selectOneById(Integer id)
    {
        return null;
    }

    // 空实现
    @Override
    public List<Attence> selectList()
    {
        return null;
    }

    // 查询考勤信息总数
    @Override
    public long selectCount()
    {
        String sql = "select count(*) from attence";
        long count = 0;
        count = (long) getSingleValue(sql);
        return count;
    }

    @Override
    public long selectCountByEmpID(int empID)
    {
        String sql = "select count(*) from Attence where empID = ?";
        long count = 0;
        count = (long) getSingleValue(sql, empID);

        return count;
    }

    @Override
    public long selectCountByEmpIDThisMonth(int empID)
    {
        String sql = "select count(*) from (select empID, datediff(now(), date) datedifferent from Attence where empID = ?) new_table where datedifferent <= 30";
        long count = 0;
        count = (long) getSingleValue(sql, empID);

        return count;
    }

    @Override
    public long selectCountByEmpIDThisYear(int empID)
    {
        String sql = "select count(*) from (select empID, datediff(now(), date) datedifferent from Attence where empID = ?) new_table where datedifferent <= 360";
        long count = 0;
        count = (long) getSingleValue(sql, empID);

        return count;
    }
}
