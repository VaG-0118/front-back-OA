package com.universityhr.dao.impl;

import com.universityhr.utils.JDBCUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class BasicDaoImpl<T>
{
    private QueryRunner qr = new QueryRunner();

    /**
     * 增删改SQL语句
     *
     * @param sql
     * @param args
     * @return
     * @throws SQLException
     */
    protected int update(String sql, Object... args) throws SQLException
    {
        Connection conn = JDBCUtils.getConnection();
        int len = qr.update(conn, sql, args);
        //QueryRunner可以帮你关闭连接
        return len;
    }

    /**
     * 查询，返回List
     *
     * @param clazz
     * @param sql
     * @param args
     * @return
     * @throws Exception
     */
    protected List<T> getList(Class<T> clazz, String sql, Object... args) throws Exception
    {
        Connection conn = JDBCUtils.getConnection();
        /*
         * ResultSetHandler接口,用于处理 java.sql.ResultSet，将数据按要求转换为另一种形式。
         * (1)BeanListHandler等形式
         */
        List<T> list = qr.query(conn, sql, new BeanListHandler<>(clazz), args);
        return list;
    }

    /**
     * 查询，返回单个实体对象
     *
     * @param clazz
     * @param sql
     * @param args
     * @return
     * @throws Exception
     */
    protected T getBean(Class<T> clazz, String sql, Object... args) throws Exception
    {
        Connection conn = JDBCUtils.getConnection();
        /*
         * ResultSetHandler接口,用于处理 java.sql.ResultSet，将数据按要求转换为另一种形式。
         * (2)BeanHandler等形式
         */
        T t = qr.query(conn, sql, new BeanHandler<>(clazz), args);
        return t;
    }

    /**
     * 通用的查询单个值的方法
     * 例如：员工总数，最高工资，平均工资等
     *
     * @param sql
     * @param args
     */
    protected Object getObject(String sql, Object... args) throws Exception
    {
        Connection conn = JDBCUtils.getConnection();
        /*
         * ResultSetHandler接口,用于处理 java.sql.ResultSet，将数据按要求转换为另一种形式。
         * (3)ScalarHandler：查询单个值对象等形式
         */
        Object obj = qr.query(conn, sql, new ScalarHandler<>(), args);
        return obj;
    }

    /**
     * 通用的查询多行多列的方法
     * 例如：每个部门的平均工资
     *
     * @param sql
     * @param args
     */
    protected List<Map<String, Object>> getMapList(String sql, Object... args) throws Exception
    {
        Connection conn = JDBCUtils.getConnection();
        /*
         * ResultSetHandler接口,用于处理 java.sql.ResultSet，将数据按要求转换为另一种形式。
         * (4)MapListHandler：将结果集中的每一行数据都封装到一个Map里，然后再存放到List
         */
        List<Map<String, Object>> list = qr.query(conn, sql, new MapListHandler(), args);
        return list;
    }

    public Object getSingleValue(String sql, Object... args)
    {
        Connection connection = null;
        Object count = null;
        try
        {
            //1.获取连接
            connection = JDBCUtils.getConnection();
            //2.调用QueryRunner中查询的方法
            count = qr.query(connection, sql, new ScalarHandler<>(), args);
        }
        catch (SQLException e)
        {
//            e.printStackTrace();
            throw new RuntimeException();
        }
        finally
        {
            //3.释放资源
//            JDBCUtils.releaseConnection(connection);
        }
        return count;
    }

}
