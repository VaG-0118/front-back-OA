package com.universityhr.dao.impl;

import com.universityhr.bean.Dept;
import com.universityhr.bean.Employee;
import com.universityhr.bean.Page;
import com.universityhr.dao.DeptDao;

import java.sql.SQLException;
import java.util.List;

public class DeptDaoImpl extends BasicDaoImpl<Dept> implements DeptDao
{
    public Integer selectIdByName(String name)
    {
        String sql = "select deptNO from dept where deptName=?";
        Integer id = (Integer) getSingleValue(sql, name);
        return id;
    }
    public String selectNameById(Integer deptno)
    {
        String sql = "select deptName from dept where deptno=?";
        String deptname = (String) getSingleValue(sql, deptno);
        return deptname;
    }
    // 按部门名和部门类型查询
    // 按部门名和部门类型查询
    @Override
    public Page<Dept> selectDeptNameAndTypeByPage(Page<Dept> page, String deptName, String deptType)
    {
        String sql = "select count(*) from dept";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select deptNO, deptName, deptType from dept where deptName=? and deptType=? limit ?,?";
        try
        {
            page.setList(
                    getList(Dept.class,
                            sql2,
                            deptName,
                            deptType,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    // 按部门类型查询所有
    public Page<Dept> selectAllByTypeByPage(Page<Dept> page, String deptType)
    {
        String sql = "select count(*) from dept";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 ="";
        if(deptType==null || deptType.equals("")){
            //deptType ="行政机构"; limit ? 0,10
            sql2 = "select deptNO, deptName, deptType from dept limit ?,?";
        }else{
            sql2 = "select deptNO, deptName, deptType from dept limit ?,?";
        }
        try
        {
            page.setList(
                    getList(Dept.class,
                            sql2,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    // 按类型统计部门数
    @Override
    public long selectCount(String deptType)
    {
        String sql = "select count(*) from dept where deptType=?";
        long count = 0;
        count = (long) getSingleValue(sql, deptType);
        return count;
    }

    // 新增部门信息
    @Override
    public int insert(Dept entity)
    {
        String sql = "insert into dept (deptNO, deptName, deptType) values(?,?,?)";
        int count = 0;
        try
        {
            count = update(sql, entity.getDeptNO(), entity.getDeptName(), entity.getDeptType());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    // 按deptNo更新
    @Override
    public int update(Dept entity)
    {
        String sql = "update dept set deptName=?, deptType=? where deptNO=?";
        int count = 0;

        try
        {
            count = update(sql, entity.getDeptName(), entity.getDeptType(), entity.getDeptNO());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;

    }

    // 按deptNo删除
    @Override
    public int deleteById(Integer id)
    {
        String sql = "delete from dept where deptNO=?";
        int count = 0;
        try
        {
            count = update(sql, id);
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    // 空实现
    @Override
    public Dept selectOneById(Integer id)
    {
        return null;
    }

    // 空实现
    @Override
    public List<Dept> selectList()
    {
        return null;
    }
}
