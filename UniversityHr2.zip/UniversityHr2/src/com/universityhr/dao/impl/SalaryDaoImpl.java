package com.universityhr.dao.impl;

import com.universityhr.bean.Page;
import com.universityhr.bean.Salary;
import com.universityhr.dao.SalaryDao;

import java.sql.SQLException;
import java.util.List;

public class SalaryDaoImpl extends BasicDaoImpl<Salary> implements SalaryDao
{
    // 插入一条工资记录
    @Override
    public int insert(Salary entity)
    {
        String sql = "insert into salary values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
        int count = 0;
        try
        {
            count = update(sql,
                    null,
                    entity.getEmpID(),
                    entity.getDeptNO(),
                    entity.getJob(),
                    entity.getStandardSalary(),
                    entity.getBonus(),
                    entity.getWorkSubsidy(),
                    entity.getOvertimePay(),
                    entity.getBelate(),
                    entity.getLeave(),
                    entity.getAbsent(),
                    entity.getSocialInsurance(),
                    entity.getDate());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    // 更新一条工资记录
    @Override
    public int update(Salary entity)
    {
        String sql = "update salary set deptNO=?," +
                "job=?," +
                "standardSalary=?," +
                "bonus=?," +
                "workSubsidy=?," +
                "overtimePay=?," +
                "belate=?," +
                "`leave`=?," +
                "absent=?," +
                "socialInsurance=?," +
                "date=? " +
                "where empID=?";
        int count = 0;
        try
        {
            count = update(sql,
                    entity.getDeptNO(),
                    entity.getJob(),
                    entity.getStandardSalary(),
                    entity.getBonus(),
                    entity.getWorkSubsidy(),
                    entity.getOvertimePay(),
                    entity.getBelate(),
                    entity.getLeave(),
                    entity.getAbsent(),
                    entity.getSocialInsurance(),
                    entity.getDate(),
                    entity.getEmpID());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;

    }

    // 根据工资表编号(ID)删除(非empID)
    @Override
    public int deleteById(Integer id)
    {
        String sql = "delete from salary where id=?";
        int count = 0;
        try
        {
            count = update(sql, id);
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;

    }

    // 按员工ID查找
    @Override
    public Salary selectOneById(Integer empID)
    {
        Salary salary = null;
        String sql = "SELECT " +
                "salary.id, " +
                "salary.empID, " +
                "emps.empName, " +
                "salary.deptNO, " +
                "dept.deptName, " +
                "job, " +
                "standardSalary, " +
                "bonus, " +
                "workSubsidy, " +
                "overtimePay, " +
                "belate, " +
                "`leave`, " +
                "absent, " +
                "socialInsurance, " +
                "date " +
                "FROM " +
                "salary, " +
                "dept, " +
                "emps " +
                "WHERE " +
                "salary.deptNO = dept.deptNO " +
                "AND emps.empId = salary.empID " +
                "AND salary.empID = ? " +
                "ORDER BY " +
                "date DESC";

        try
        {
            salary = getBean(Salary.class, sql, empID);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return salary;
    }

    // 空实现
    @Override
    public List<Salary> selectList()
    {
        return null;
    }

    // 查询某empID下所有工资记录
    @Override
    public Page<Salary> selectEmpIDByPage(Page<Salary> page, int empID)
    {
        String sql = "select count(*) from salary";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
//        String sql2 = "select * from salary where empID = ? order by date desc limit ?,?";
        String sql2 = "SELECT " +
                "salary.id, " +
                "salary.empID, " +
                "emps.empName, " +
                "salary.deptNO, " +
                "dept.deptName, " +
                "job, " +
                "standardSalary, " +
                "bonus, " +
                "workSubsidy, " +
                "overtimePay, " +
                "belate, " +
                "`leave`, " +
                "absent, " +
                "socialInsurance, " +
                "date " +
                "FROM " +
                "salary, " +
                "dept, " +
                "emps " +
                "WHERE " +
                "salary.deptNO = dept.deptNO " +
                "AND emps.empId = salary.empID " +
                "AND salary.empID = ? " +
                "ORDER BY " +
                "date DESC " +
                "LIMIT ?, ?";
        try
        {
            page.setList(getList(Salary.class, sql2, empID, (page.getPageNo() - 1) * page.getPageSize(), page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }


    // 查询所有工资记录
    @Override
    public Page<Salary> selectAllSalaryByPage(Page<Salary> page)
    {
        String sql = "select count(*) from salary";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "SELECT " +
                "salary.id, " +
                "salary.empID, " +
                "emps.empName, " +
                "salary.deptNO, " +
                "dept.deptName, " +
                "job, " +
                "standardSalary, " +
                "bonus, " +
                "workSubsidy, " +
                "overtimePay, " +
                "belate, " +
                "`leave`, " +
                "absent, " +
                "socialInsurance, " +
                "date " +
                "FROM " +
                "salary, " +
                "dept, " +
                "emps " +
                "WHERE " +
                "salary.deptNO = dept.deptNO " +
                "AND emps.empId = salary.empID " +
                "ORDER BY " +
                "date DESC " +
                "LIMIT ?, ?";
        try
        {
            page.setList(getList(Salary.class, sql2, (page.getPageNo() - 1) * page.getPageSize(), page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    // 查询本月某empID所有工资记录
    @Override
    public Page<Salary> selectEmpIDByPageThisMonth(Page<Salary> page, int empID)
    {
        String sql = "select count(*) from salary where (SELECT DATEDIFF(now(), date) <= 30)";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "SELECT id, empID,empName,deptNO,deptName,job,standardSalary,bonus,workSubsidy,overtimePay," +
                "belate,`leave`,absent,socialInsurance,date FROM (SELECT salary.id,salary.empID,emps.empName," +
                "salary.deptNO,dept.deptName,job,standardSalary,bonus,workSubsidy," +
                "overtimePay,belate,`leave`,absent,socialInsurance,date," +
                "DATEDIFF( now(), date ) datedifference FROM salary,dept,emps WHERE salary.deptNO = dept.deptNO" +
                " AND emps.empId = salary.empID AND salary.empID = ?) new_table WHERE datedifference <= 30" +
                " ORDER BY date desc limit ?, ?";
        try
        {
            page.setList(getList(Salary.class, sql2, empID, (page.getPageNo() - 1) * page.getPageSize(), page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    // 查询本年某empID所有工资记录
    @Override
    public Page<Salary> selectEmpIDByPageThisYear(Page<Salary> page, int empID)
    {
        String sql = "select count(*) from salary where (SELECT DATEDIFF(now(), date) <= 360)";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "SELECT id, empID,empName,deptNO,deptName,job,standardSalary,bonus,workSubsidy,overtimePay," +
                "belate,`leave`,absent,socialInsurance,date FROM (SELECT salary.id,salary.empID,emps.empName," +
                "salary.deptNO,dept.deptName,job,standardSalary,bonus,workSubsidy," +
                "overtimePay,belate,`leave`,absent,socialInsurance,date," +
                "DATEDIFF( now(), date ) datedifference FROM salary,dept,emps WHERE salary.deptNO = dept.deptNO" +
                " AND emps.empId = salary.empID AND salary.empID = ?) new_table WHERE datedifference <= 360" +
                " ORDER BY date desc limit ?, ?";
        try
        {
            page.setList(getList(Salary.class, sql2, empID, (page.getPageNo() - 1) * page.getPageSize(), page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    // 统计总共有多少条工资记录
    @Override
    public long selectCount()
    {
        String sql = "select count(*) from salary";
        long count = 0;
        count = (long) getSingleValue(sql);
        return count;
    }

    // 统计某员工总共有多少条工资记录
    @Override
    public long selectCountByEmpID(int empID)
    {
        String sql = "select count(*) from salary where empID = ?";
        long count = 0;
        count = (long) getSingleValue(sql, empID);

        return count;
    }

    // 统计某员工本月有多少条工资记录
    @Override
    public long selectCountByEmpIDThisMonth(int empID)
    {
        String sql = "select count(*) from (select empID, datediff(now(), date) datedifferent from salary where empID = ?) new_table where datedifferent <= 30";
        long count = 0;
        count = (long) getSingleValue(sql, empID);

        return count;
    }

    // 统计某员工本年有多少条工资记录
    @Override
    public long selectCountByEmpIDThisYear(int empID)
    {
        String sql = "select count(*) from (select empID, datediff(now(), date) datedifferent from salary where empID = ?) new_table where datedifferent <= 360";
        long count = 0;
        count = (long) getSingleValue(sql, empID);

        return count;
    }
}
