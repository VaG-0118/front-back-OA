package com.universityhr.dao.impl;

import com.universityhr.bean.Employee;
import com.universityhr.bean.Page;
import com.universityhr.dao.BasicDao;
import com.universityhr.dao.EmployeeDao;

import java.sql.SQLException;
import java.util.List;

public class EmployeeDaoImpl extends BasicDaoImpl<Employee> implements EmployeeDao<Employee>
{
    @Override
    public int insert(Employee entity)
    {
        String sql = "insert into emps values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        int count = 0;
        try
        {
            count = update(sql,
                    null,
                    entity.getEmpName(),
                    entity.getGender(),
                    entity.getBirthday(),
                    entity.getPoliticalStatus(),
                    entity.getDeptNO(),
                    entity.getProfessionalTitle(),
                    entity.getEmpStatus(),
                    entity.getEmpAddress(),
                    entity.getEmailAddr(),
                    entity.getTelephone(),
                    entity.getQQ(),
                    entity.getEducation(),
                    entity.getUniversity(),
                    entity.getIntro());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }


    //根据empID更新个人资料
    @Override
    public int update(Employee entity)
    {
        String sql = "update emps set empName=?," +
                " gender=?," +
                " birthday=?," +
                " politicalStatus=?," +
                " deptNO=?," +
                " professionalTitle=?," +
                " empStatus=?," +
                " empAddress=?," +
                " emailAddr=?," +
                " telephone=?," +
                " QQ=?," +
                "education=?," +
                "university=?," +
                "intro=?" +
                " where empID=?";
        int count = 0;
        try
        {
            count = update(sql,
                    entity.getEmpName(),
                    entity.getGender(),
                    entity.getBirthday(),
                    entity.getPoliticalStatus(),
                    entity.getDeptNO(),
                    entity.getProfessionalTitle(),
                    entity.getEmpStatus(),
                    entity.getEmpAddress(),
                    entity.getEmailAddr(),
                    entity.getTelephone(),
                    entity.getQQ(),
                    entity.getEducation(),
                    entity.getUniversity(),
                    entity.getIntro(),
                    entity.getEmpID());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    @Override
    public int deleteById(Integer id)
    {
        String sql = "delete from emps where empid=?";
        int count = 0;
        try
        {
            count = update(sql, id);
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    @Override
    public Employee selectOneById(Integer id)
    {
        Employee employee = null;
        String sql = "select * from emps where empID=?";
        try
        {
            employee = getBean(Employee.class, sql, id);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return employee;
    }

    @Override
    public List<Employee> selectList()
    {
        String sql = "select * from emps";
        List<Employee> list = null;
        try
        {
            list = getList(Employee.class, sql);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return list;
    }

    @Override
    public Employee selectByName(String empname)
    {
        Employee employee = null;
        String sql = "select * from emps where empname=?";
        try
        {
            employee = getBean(Employee.class, sql, empname);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return employee;
    }

    // 更新员工在职状态
    @Override
    public int setEmpStatus(String empname, Integer newStatus)
    {
        String sql = "update emps set empStatus=? where empname=?";
        int count = 0;
        try
        {
            count = update(sql, newStatus, empname);
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    @Override
    public Page<Employee> selectByPage(Page<Employee> page)
    {
        String sql = "select count(*) from emps";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select * from emps limit ?,?";
        try
        {
            page.setList(getList(Employee.class, sql2, (page.getPageNo() - 1) * page.getPageSize(), page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    @Override
    public long selectCount()
    {
        String sql = "select count(*) from emps";
        long count = 0;
        count = (long) getSingleValue(sql);
        return count;
    }
}
