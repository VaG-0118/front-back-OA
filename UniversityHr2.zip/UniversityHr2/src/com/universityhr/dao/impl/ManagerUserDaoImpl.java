package com.universityhr.dao.impl;

import com.universityhr.bean.ManagerUser;
import com.universityhr.dao.ManagerUserDao;

import java.sql.SQLException;

public class ManagerUserDaoImpl extends BasicDaoImpl<ManagerUser> implements ManagerUserDao<ManagerUser>
{

    @Override
    public ManagerUser getUser(String username)
    {
        ManagerUser ManagerUser = null;
        String sql = "select * from staffusers where username=?";
        try
        {
            ManagerUser = getBean(com.universityhr.bean.ManagerUser.class, sql, username);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return ManagerUser;
    }

    @Override
    public int saveUser(ManagerUser user)
    {
        String sql = "update managerusers set password=?, email=? where username=?";
        int count = 0;
        try
        {
            count = update(sql, user.getPassword(), user.getEmail(), user.getUsername());
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return count;
    }

    @Override
    public int addUser(ManagerUser user)
    {
        String sql = "insert into managerusers values(?,?,?,?)";
        int count = 0;
        try
        {
            count = update(sql, null, user.getUsername(), user.getPassword(), user.getEmail());
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }
}
