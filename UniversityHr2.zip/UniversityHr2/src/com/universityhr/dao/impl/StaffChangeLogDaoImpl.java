package com.universityhr.dao.impl;

import com.universityhr.bean.Page;
import com.universityhr.bean.StaffChangeLog;
import com.universityhr.dao.StaffChangeLogDao;

import java.sql.SQLException;
import java.util.List;

public class StaffChangeLogDaoImpl extends BasicDaoImpl<StaffChangeLog> implements StaffChangeLogDao
{

    // 插入数据
    @Override
    public int insert(StaffChangeLog entity)
    {
        String sql = "insert into empschanged(empID, name, post, type, date) values(?,?,?,?,?)";
        int count = 0;
        try
        {
            count = update(sql, entity.getEmpID(), entity.getName(), entity.getPost(), entity.getType(), entity.getDate());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;

    }

    // 根据ID更新记录
    @Override
    public int update(StaffChangeLog entity)
    {
        String sql = "update empschanged set name=?, post=?, type=?, date=? where id=?";
        int count = 0;
        try
        {
            count = update(sql, entity.getName(), entity.getPost(), entity.getType(), entity.getDate(), entity.getId());
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }


    @Override
    public int deleteById(Integer id)
    {
        String sql = "delete from empschanged where id=?";
        int count = 0;
        try
        {
            count = update(sql, id);
        }
        catch (SQLException throwables)
        {
            throwables.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }

    // 空实现
    @Override
    public StaffChangeLog selectOneById(Integer id)
    {
        return null;
    }

    // 空实现
    @Override
    public List<StaffChangeLog> selectList()
    {
        return null;
    }

    @Override
    public Page<StaffChangeLog> selectAllLog(Page<StaffChangeLog> page)
    {
        String sql = "select count(*) from empschanged";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select id, name, post, type, date from empschanged limit ?,?";
        try
        {
            page.setList(
                    getList(StaffChangeLog.class,
                            sql2,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    @Override
    public Page<StaffChangeLog> selectAllLogByEmpID(Page<StaffChangeLog> page, Integer empID)
    {
        String sql = "select count(*) from empschanged";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select id, name, post, type, date from empschanged where empID = ? order by date desc limit ?,?";
        try
        {
            page.setList(
                    getList(StaffChangeLog.class,
                            sql2,
                            empID,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }

    @Override
    public Page<StaffChangeLog> selectAllLogByType(Page<StaffChangeLog> page, String type)
    {
        String sql = "select count(*) from empschanged";
        long count = 0;
        count = (long) getSingleValue(sql);
        page.setTotalRecord((int) count);
        String sql2 = "select id, name, post, type, date from empschanged where type = ? order by date desc limit ?,?";
        try
        {
            page.setList(
                    getList(StaffChangeLog.class,
                            sql2,
                            type,
                            (page.getPageNo() - 1) * page.getPageSize(),
                            page.getPageSize()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return page;
    }
}
