package com.universityhr.dao.impl;

import com.universityhr.bean.StaffUser;
import com.universityhr.dao.StaffUserDao;

import java.sql.SQLException;

public class StaffUserDaoImpl extends BasicDaoImpl<StaffUser> implements StaffUserDao<StaffUser>
{
    // 查询用户信息
    @Override
    public StaffUser getUser(String username)
    {
        StaffUser staffUser = null;
        String sql = "select * from staffusers where username=?";
        try
        {
            staffUser = getBean(StaffUser.class, sql, username);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return staffUser;
    }

    // 更新用户信息
    @Override
    public int saveUser(StaffUser user)
    {
        String sql = "update staffusers set password=?, email=? where username=?";
        int count = 0;
        try
        {
            count = update(sql, user.getPassword(), user.getEmail(), user.getUsername());
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }

        return count;
    }

    // 新增用户信息
    @Override
    public int addUser(StaffUser user)
    {
        String sql = "insert into staffusers values(?,?,?,?)";
        int count = 0;
        try
        {
            count = update(sql, null, user.getUsername(), user.getPassword(), user.getEmail());
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return count;
    }
}
