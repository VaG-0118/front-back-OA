package com.universityhr.dao;

import com.universityhr.bean.File;
import com.universityhr.bean.Page;

public interface FileDao extends BasicDao<File>
{
    Page<File> selectFileByPage(Page<File> page);

    File selectFileName(String fileName);

    long selectCount();
}
