package com.universityhr.dao;

import com.universityhr.bean.ManagerUser;

public interface ManagerUserDao<T>
{
    // 获取用户
    ManagerUser getUser(String username);

    // 更新、保存用户信息
    int saveUser(T staffUser);

    // 添加用户
    int addUser(T staffUser);

}
