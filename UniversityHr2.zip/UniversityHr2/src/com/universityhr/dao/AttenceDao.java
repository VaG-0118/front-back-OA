package com.universityhr.dao;

import com.universityhr.bean.Attence;
import com.universityhr.bean.Page;

public interface AttenceDao extends BasicDao<Attence>
{
    long selectAttenceInfoByEmpID(Integer empID, String attenceInfo);

    Page<Attence> selectAllAttenceByPage(Page<Attence> page);

    Page<Attence> selectAllAttenceByEmpIDByPage(Page<Attence> page, int empID);

    Page<Attence> selectAttenceByEmpIDThisMonth(Page<Attence> page, int empID);

    Page<Attence> selectAttenceByEmpIDThisYear(Page<Attence> page, int empID);

    long selectCount();

    long selectCountByEmpID(int empID);

    long selectCountByEmpIDThisMonth(int empID);

    long selectCountByEmpIDThisYear(int empID);
}
