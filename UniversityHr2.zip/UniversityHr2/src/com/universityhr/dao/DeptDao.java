package com.universityhr.dao;

import com.universityhr.bean.Dept;
import com.universityhr.bean.Page;

public interface DeptDao extends BasicDao<Dept>
{
    Page<Dept> selectDeptNameAndTypeByPage(Page<Dept> page, String deptName, String deptType);

    Page<Dept> selectAllByTypeByPage(Page<Dept> page, String deptType);

    long selectCount(String deptType);
    Integer selectIdByName(String name);
    String selectNameById(Integer deptno);
}
