package com.universityhr.dao;

import java.util.List;

// DAO - Data Access Object
public interface BasicDao<T>
{
    /**
     * 向数据库中添加实体信息的方法
     *
     * @param entity
     */
    int insert(T entity);

    /**
     * 更新实体信息的方法
     * 使用要有主键值
     *
     * @param entity
     */
    int update(T entity);

    /**
     * 根据实体id删除实体的方法
     *
     * @param id
     */
    int deleteById(Integer id);

    /**
     * 根据实体id查询实体信息的方法
     */
    T selectOneById(Integer id);

    /*
    查询数据库中所有实体的方法
     */
    List<T> selectList();

}
